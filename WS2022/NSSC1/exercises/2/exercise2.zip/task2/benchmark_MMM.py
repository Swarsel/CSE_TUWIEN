import matplotlib.pyplot as plt

N = [64, 128, 256, 500, 512, 1000, 1024, 1500]
CUSTOM = [0.000104298, 0.00825462, 0.0419069, 0.111161, 0.27142, 2.88954, 19.7925, 74.3821]
OPENBLAS = [0.00364825, 0.00702863, 0.00334693, 0.0146784, 0.0384113, 0.0631997, 0.12933, 0.196736]
EIGEN = [0.000205624, 0.00104274, 0.00467221, 0.0424528, 0.0597755, 0.22353, 0.215379, 0.659907]


runtime = [2*n**3/(7*8*1e9) for n in N]
plt.plot(N, CUSTOM, label = "CUSTOM")
plt.plot(N, OPENBLAS, label = "OPENBLAS")
plt.plot(N, EIGEN, label = "EIGEN")
plt.plot(N, runtime, label = "peak performance")
plt.legend()
plt.yscale("log")
plt.xlabel("N")
plt.ylabel("runtime in seconds")
plt.show()