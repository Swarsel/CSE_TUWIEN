import matplotlib.pyplot as plt
import numpy as np

with open("output_triad.txt", "r") as file:
    result = np.array([[float(x) for x in line.split(", ")] for line in file])

# https://www.techpowerup.com/cpu-specs/core-i7-4770k.c1459
# i7-4770K cache:
# L3: 8MB = 8192 KB shared
# L2: 256KB per core
# L1: 64KB per core

footprint = result[:,1]
cache = np.array([64, 256, 8192])
calc = np.array([c/(4*8)*1024 for c in cache])

plt.semilogx(result[:,0],result[:,-1])

plt.axvline(x=calc[0], color="r",label="L1 cache")
plt.axvline(x=calc[1], color="g",label="L2 cache")
plt.axvline(x=calc[2], color="c",label="L3 cache")
plt.xlabel("N")
plt.ylabel("Flops/sec")
plt.ylim(0)
plt.legend()
plt.show()
