#include<iostream>
#include<cassert>
#include <sstream>
#include <string>
#include <vector>
#include <cmath>
#include <chrono>

using namespace std;

// function for the bound on the upper limit y=1
double bound(double x) {
    return sin(2.0*M_PI*x)*sinh(2.0*M_PI);
}

double u_p(double x, double y) {
    return sin(2.0*M_PI*x)*sinh(2.0*M_PI*y);
}

int main(int argc, char *argv[]){
    // parse command line arguments
    assert(argc == 3);
    size_t res = 32;
    size_t its = 100;
    {
        istringstream tmp(argv[1]);
        tmp >> res;
    }
    {
        istringstream tmp(argv[2]);
        tmp >> its;
    }
    std::cout << "resolution=" << res << std::endl;
    std::cout << "iterations=" << its << std::endl;

    double h = 1.0/(res-1.0); 
    double k = 2*M_PI;

    // constructing u with total grid (bounds included), but bounds will not be changed
    vector<double> u;
    for (size_t i=0; i<(res*(res-1)); i++) {
        u.push_back(0);
    }
    for (size_t i = 0; i < res; i++) {
        u.push_back(bound(i*h));
    }

    vector<double> u_old;
    for (size_t i=0; i<(res*res); i++) {
        u_old.push_back(0);
    }
    vector<double> b;
    for (size_t i=1; i <res-1; i++){
            for (size_t j=1; j <res-1; j++){
                b.push_back(u_p(j*h,i*h));
            }
    }

    double D = 4.0 + h*h*k*k;
    double C1 = h*h/D;
    double C2 = 1.0/(h*h);
    double C3 = k*k;
    size_t x;
    //Jacobi method without matrix u_new = u + h²/(4+h²k²) * (k²*u_c + 1/h² * ((4+h²k²) * u_c - u_N - u_I - u_S - u_W)))
    chrono::steady_clock::time_point t1 = chrono::steady_clock::now();
    for (size_t k=0; k <its; k++) {
        u_old = u;
        size_t count = 0;
        for (size_t i=1; i <res-1; i++){
            for (size_t j=1; j <res-1; j++){
                x = res*i+j;
                u[x] += C1 * (C3*b[count] + 
                              C2 *(-(D)*u_old[x] + u_old[x+res] + u_old[x+1] + u_old[x-res] + u_old[x-1]));
                count++;
            }
        }
    }
    chrono::steady_clock::time_point t2 = chrono::steady_clock::now();
    chrono::duration<double> time_span = chrono::duration_cast<chrono::duration<double>>(t2-t1);

    // norms
    double eucld_res= 0.0, maximum_res = 0.0;
    double eucld_tot = 0.0, maximum_tot = 0.0;
  
    size_t count = 0;
    for (size_t i=1; i <res-1; i++){
        for (size_t j=1; j <res-1; j++){
            x = res*i+j;
            double residual = C2 * ((D)*u[x] - u[res+x] - u[x+1] - u[x-res] - u[x-1]) - C3*b[count];
            if (fabs(residual) > maximum_res) {
                maximum_res = fabs(residual);
            }
            eucld_res += residual * residual;
            double tot_error = fabs(u[x] - b[count]);
            if (tot_error > maximum_tot) {
                maximum_tot = tot_error;
            }
            eucld_tot += tot_error * tot_error;
            count++;
        }
    }

    cout << "runtime: " << time_span.count() << "s." << endl;
    cout << "euclidean norm of residual: " << sqrt(eucld_res) << endl;
    cout << "maximum norm of residual: " << maximum_res << endl;
    cout << "euclidean norm of total error: " << sqrt(eucld_tot) << endl;
    cout << "maximum norm of total error: " << maximum_tot << endl;
    return 0;
}