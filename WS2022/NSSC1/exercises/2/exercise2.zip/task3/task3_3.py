import numpy as np
import matplotlib.pyplot as plt

resolution = [16,32,64,128,256]
its = np.array([1,5,10,50,75,100,150]) * 1E3
euc_res = [924666,102462,14448.1,0.0148231,2.95016E-06,8.93504E-07,8.94194E-07]
max_res = [15023.1,1114.5,133.794,0.000116261,2.60497E-08,3.84089E-08,3.84089E-08]
euc_tot = [5748.96,986.44,153.858,0.308631,0.308737,0.308737,0.308737]
max_tot = [72.8119,9.8039,1.35494,0.00343598,0.00343651,0.00343651,0.00343651]
euc_tot2 = [5.14479,2.52848,1.2484,0.619784,0.308737]
max_tot2 = [0.966002,0.230887,0.056153,0.0138502,0.00343651]



plt.loglog(its,euc_res, color="r",label="euclidean norm of residual")
plt.loglog(its,max_res, "--r", label="maximum norm of residual")
plt.loglog(its,euc_tot, color="b", label="euclidean norm of total error")
plt.loglog(its,max_tot, "--b", label="maximum norm of total error")
plt.legend()
plt.title("norms at resolution=256")
plt.xlabel("iterations")
plt.ylabel("norm")
plt.show()

plt.loglog(resolution,euc_tot2, color="b",label="euclidean norm of total error")
plt.loglog(resolution,max_tot2, "--b", label="maximum norm of total error")
plt.legend()
plt.xticks(resolution,[16,32,64,128,256])
plt.xlabel("resolution")
plt.title("norms at sufficient number of iterations")
plt.ylabel("norm")
plt.show()