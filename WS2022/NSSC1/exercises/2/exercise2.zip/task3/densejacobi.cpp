#include<iostream>
#include<cassert>
#include <sstream>
#include <string>
#include <vector>
#include <cmath>
#include <chrono>
#include <eigen3/Eigen/Dense>
using namespace Eigen;

using namespace std;

// function for the bound on the upper limit y=1
double bound(double x) {
    return sin(2.0*M_PI*x)*sinh(2.0*M_PI);
}

double u_p(double x, double y) {
    return sin(2.0*M_PI*x)*sinh(2.0*M_PI*y);
}

int main(int argc, char *argv[]){
    // parse command line arguments
    assert(argc == 3);
    size_t res = 32;
    int its = 100;
    {
        istringstream tmp(argv[1]);
        tmp >> res;
    }
    {
        istringstream tmp(argv[2]);
        tmp >> its;
    }
    std::cout << "resolution=" << res << std::endl;
    std::cout << "iterations=" << its << std::endl;

    double h = 1.0/(res-1.0); 
    double k = 2*M_PI;


    //construction of matrix A with D and I
    MatrixXd A ((res-2)*(res-2),(res-2)*(res-2));
    MatrixXd D = (4+h*h*k*k) * MatrixXd::Identity((res-2),(res-2));
    for (size_t i=0; i<((res-2)-1); i++) {
        D(i,i+1) = -1.0;
        D(i+1,i) = -1.0;
    }
    MatrixXd I = -1 * MatrixXd::Identity((res-2),(res-2));
    // we insert the blocks D and I into A at the respective indices
    for (size_t i=0; i<(res-2)*(res-2); i+=(res-2)) {
        A.block(i,i,(res-2),(res-2)) = D;
        if (i>=(res-2)*(res-2-1)) {
            break;
        }
        A.block(i,i+(res-2),res-2,res-2) = I;
        A.block(i+(res-2),i,res-2,res-2) = I;

    }
    A*= 1.0/(h*h); // Matrix A is 1/h² * (...)

    //construction of vector b
    VectorXd b ((res-2)*(res-2));
    size_t ind = 0;
    for (size_t i = 1; i < (res-1); i++) {
        for (size_t j = 1; j < (res-1); j++) {
            if (i<(res-2)*(res-3))
                b(ind) = k*k*u_p(j*h,i*h);
            else // only in the last res-2 elements we have bounds != 0
                b(ind) = k*k*u_p(j*h,i*h) + bound(j*h)/(h*h);
            ind++;
        }
    }

    // setting up the Jacobi Method
    // x_(k+1) = D^1(b-Rx) = D^1(b-(A-D)x) = D^-1(b-Ax)+x
    //D^-1 has only diagonal elements h²/(4+h²k²)
    VectorXd u = VectorXd((res-2)*(res-2)).setZero();
    double d = h*h/(4.0+h*h*k*k);
    chrono::steady_clock::time_point t1 = chrono::steady_clock::now();
    for (int i = 0; i < its; i++) {
        u += d *(b-A*u);
    }
    chrono::steady_clock::time_point t2 = chrono::steady_clock::now();
    chrono::duration<double> time_span = chrono::duration_cast<chrono::duration<double>>(t2-t1);

    VectorXd residual = A*u-b;
    // u_calc are the values of u_p at the inner points
    VectorXd u_calc((res-2)*(res-2));
    size_t k2 = 0;
    for (size_t i = 1; i < (res-1); i++) {
        for (size_t j = 1; j < (res-1); j++) {
            u_calc(k2) = u_p(j*h,i*h);
            k2++;
        }
    }
    VectorXd tot_err = u - u_calc;
    cout << "runtime: " << time_span.count() << "s." << endl;
    cout << "euclidean norm of residual: " << residual.norm() << endl;
    cout << "maximum norm of residual: " << residual.lpNorm<Infinity>() << endl;
    cout << "euclidean norm of total error: " << tot_err.norm() << endl;
    cout << "maximum norm of total error: " << tot_err.lpNorm<Infinity>() << endl;
    return 0;
}