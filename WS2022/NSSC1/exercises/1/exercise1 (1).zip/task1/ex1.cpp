#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <sstream>
using namespace std;

// task a)
struct cpu 
{
    string vendor;
    string model;
    int cores;
    int bit_arch;
    int64_t transistors;
};

//used to remove spaces from strings
string rm_spaces(string word)
{
    for (int i=word.length(); i>=0; i--)
    {
        if (' ' == word[i])
        {
            word.erase(i,1);
        }
    }
    return word;
}

// task b)
vector<cpu> txt_read(string file)
{
    vector<cpu> data;
    ifstream cpu_file(file);
    cpu CPU_txt;
    string line;
    if(cpu_file.is_open())
    {
        // read one line of file
        while(getline(cpu_file,line))
        {
            // read one element of the line with stringstream
            stringstream sstr(line);
            getline(sstr,CPU_txt.vendor,',');
            getline(sstr,CPU_txt.model,',');
            CPU_txt.model.erase(0,1); // remove the leading space
            string temp;
            getline(sstr,temp,',');
            CPU_txt.cores = stoi(rm_spaces(temp)); // convert the string to integer
            getline(sstr,temp,',');
            CPU_txt.bit_arch = stoi(rm_spaces(temp));
            getline(sstr,temp,',');
            CPU_txt.transistors = stol(rm_spaces(temp));
            data.push_back(CPU_txt); // the data is stored in a vector
        }
        cpu_file.close();
    }
    else
        cout<<"file" << file << " not open"<<endl;
    return data;
}

// task c)
string largest_core_count(vector<cpu> data)
{
    string model;
    int cores = 0;
    for(size_t i=0;i<data.size();i++)
    {
        // if there is a model with higher number of cores, 
        // set this model as the new model with highest core count
        if (data[i].cores > cores)
        {
            cores = data[i].cores;
            model = data[i].model;
        };
    };
    return model;
}

// task d)
double average_transistor(vector<cpu> data)
{
    double average = 0.0;
    for(size_t i=0;i<data.size();i++)
        average += data[i].transistors;
    return average/data.size();
}

// task e)
double ratio(cpu cpu_)
{
    return cpu_.transistors/cpu_.cores;
}

int main(int argc, char **argv)
{
    vector<string> files;
    vector<int> years;
    if (argc != 4)
    {
        cout << "Not enough filenames provided!" << endl;
        cout << "Program will use 1999_CPUs.txt 2006_CPUs.txt 2022_CPUs.txt" << endl;
        files.push_back("1999_CPUs.txt");
        years.push_back(1999);
        files.push_back("2006_CPUs.txt");
        years.push_back(2006);
        files.push_back("2022_CPUs.txt");
        years.push_back(2022);
    }
    else
    {
        for (int i = 1; i<argc; i++)
        {
            // store filenames given via command line arguments
            string str = argv[i];
            files.push_back(str);
            years.push_back(stoi(str.substr(0,4))); // years are first 4 characters of filename
        }
    }

    // task f)
    vector<cpu> cpu_1999 = txt_read(files[0]);
    vector<cpu> cpu_2006 = txt_read(files[1]);
    vector<cpu> cpu_2022 = txt_read(files[2]);
    if ((cpu_1999.size() == 0) || (cpu_2006.size() == 0) || (cpu_2022.size() == 0))
    {
        cout << "Could not open all files, exiting." << endl;
        return 1;
    }
    vector<vector<cpu>> cpu_data{ cpu_1999, cpu_2006, cpu_2022 };

    // task g)
    ofstream ostr_1;
    ostr_1.open("CPU_analysis1.txt");
    double max_cores = 0.0;
    string max_model;
    double max_ratio = 0.0;
    for (size_t i=0; i<cpu_data.size();i++)
    {
        string model = largest_core_count(cpu_data[i]); //model with largest core count
        for (size_t j=0; j<cpu_data[i].size();j++)
        {
            // find the model in the data
            if (cpu_data[i][j].model == model)
            {
                // calculate the ratio if model has highest core count so far
                if (cpu_data[i][j].cores > max_cores)
                {
                    max_cores = cpu_data[i][j].cores;
                    max_model = model;
                    max_ratio = ratio(cpu_data[i][j]);
                }
                break;
            }
        }
    }
    ostr_1 << max_model << "," << max_ratio;
    ostr_1.close();

    // task h)
    ofstream ostr_2;
    ostr_2.open("CPU_analysis2.txt");
    for (size_t i=0; i<cpu_data.size();i++)
    {
        ostr_2 << years[i] << "," << average_transistor(cpu_data[i]) << endl;
    }
    ostr_2.close();
        
    // task i)
    double increase1_abs = average_transistor(cpu_data[1]) - average_transistor(cpu_data[0]);
    double increase1_rel = increase1_abs / average_transistor(cpu_data[0]);

    double increase2_abs = average_transistor(cpu_data[2]) - average_transistor(cpu_data[1]);
    double increase2_rel = increase1_abs / average_transistor(cpu_data[1]);

    double increase3_abs = average_transistor(cpu_data[2]) - average_transistor(cpu_data[0]);
    double increase3_rel = increase3_abs / average_transistor(cpu_data[0]);

    // task j)
    ofstream ostr_3;
    ostr_3.open("CPU_analysis3.txt");
    ostr_3.precision(2); // 2 digits after decimal point
    ostr_3 << fixed;
    ostr_3 << years[0] << "-" << years[1] << ", " << increase1_abs << ", " << increase1_rel << endl;
    ostr_3 << years[1] << "-" << years[2] << ", " << increase2_abs << ", " << increase2_rel << endl;
    ostr_3 << years[0] << "-" << years[2] << ", " << increase3_abs << ", " << increase3_rel << endl;
    ostr_3.close();
    return 0;

}
