//
// Created by leons on 10/25/22.
//

#include <string>
#include <sstream>
#include <cassert>
#include <fstream>
#include "functions.h"
std::vector<std::vector<double>> readMatrix(const std::string& filename) {
    std::string line{};
    std::ifstream infile(filename);
    std::vector<std::vector<double>> matrix{};

    while (std::getline(infile, line)) {
        std::istringstream iss(line);
        std::string substring{};
        std::vector<double> substrings{};
        while (std::getline(iss, substring, ' ')) {
            substrings.push_back(std::stod(substring));
        }
        matrix.push_back(substrings);
    }
    infile.close();
    return matrix;
}

std::vector<double> readVector(const std::string& filename) {
    std::string line{};
    std::ifstream infile(filename);
    std::vector<double> vector{};

    while (std::getline(infile, line)) {
        std::istringstream iss(line);
        vector.push_back(std::stod(line));
    }
    infile.close();
    return vector;
}

std::vector<std::vector<double>> outerProduct(const std::vector<double>& vectorA,const std::vector<double>&  vectorB) {
    std::vector<std::vector<double>> matrix{};
    uint8_t arraySizeA = vectorA.size();
    uint8_t arraySizeB = vectorB.size();
    for (int i = 0; i < arraySizeA; i++) {
        std::vector<double> row{};
        for (int j = 0; j < arraySizeB; j++) {
            row.push_back(vectorA[i] * vectorB[j]);
        }
        matrix.push_back(row);
    }
    return matrix;
}

double dotProduct(const std::vector<double>& vectorA,const std::vector<double>&  vectorB) {
    double sum{0};

    uint8_t arraySizeA = vectorA.size();
    uint8_t arraySizeB = vectorB.size();
    assert(arraySizeA == arraySizeB);

    for (int i = 0; i < arraySizeA; i++) {
        sum += vectorA[i] * vectorB[i];
    }
    return sum;
}

std::vector<std::vector<double>> matrixMatrix(std::vector<std::vector<double>> matrixA, std::vector<std::vector<double>> matrixB) {
    std::vector<std::vector<double>> matrix{};
    uint8_t arraySizeA = matrixA.size();
    uint8_t arraySizeB = matrixB.size();
    assert(arraySizeA == arraySizeB);

    for (int i = 0; i < arraySizeA; i++) {
        std::vector<double> row{};
        for (int j = 0; j < arraySizeB; j++) {
            row.push_back(dotProduct(matrixA[i], matrixB[j]));
        }
        matrix.push_back(row);
    }
    return matrix;
}

std::vector<std::vector<double>> scalarMatrix(double scalar, std::vector<std::vector<double>> matrixIn) {
    std::vector<std::vector<double>> matrix{};
    uint8_t arraySize = matrixIn.size();

    for (int i = 0; i < arraySize; i++) {
        std::vector<double> row{};
        for (int j = 0; j < arraySize; j++) {
            row.push_back(scalar * matrixIn[i][j]);
        }
        matrix.push_back(row);
    }
    return matrix;
}

void writeFile(const std::string& filename, std::vector<std::vector<double>> matrix) {
    std::ofstream outFile(filename);
    uint8_t columnSize = matrix.size();
    uint8_t rowSize = matrix[0].size();

    for (int i = 0; i < columnSize; i++) {
        for (int j = 0; j < rowSize; j++) {
            outFile << matrix[i][j] << " ";
        }
        outFile << std::endl;
    }
    outFile.close();

}