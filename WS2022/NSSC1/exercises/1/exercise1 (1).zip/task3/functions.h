//
// Created by leons on 10/25/22.
//

#ifndef T3_FUNCTIONS_H
#define T3_FUNCTIONS_H

#include <vector>

std::vector<std::vector<double>> readMatrix(const std::string& filename);
std::vector<double> readVector(const std::string& filename);
std::vector<std::vector<double>> outerProduct(const std::vector<double>& vectorA,const std::vector<double>&  vectorB);
double dotProduct(const std::vector<double>& vectorA,const std::vector<double>&  vectorB);
std::vector<std::vector<double>> matrixMatrix(std::vector<std::vector<double>> matrixA, std::vector<std::vector<double>> matrixB);
std::vector<std::vector<double>> scalarMatrix(double scalar, std::vector<std::vector<double>> matrixIn);
void writeFile(const std::string& filename, std::vector<std::vector<double>> matrix);

#endif //T3_FUNCTIONS_H