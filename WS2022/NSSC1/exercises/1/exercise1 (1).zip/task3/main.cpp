#include <iostream>
#include "functions.h"

int main() {
    std::vector<std::vector<double>> matrix = readMatrix("MatrixA.txt");
    std::vector<double> vector = readVector("VectorV.txt");

    std::vector<std::vector<double>> outer = outerProduct(vector, vector);
    double dot = dotProduct(vector, vector);
    std::vector<std::vector<double>> calc = scalarMatrix(dot, matrixMatrix(matrix, outer));

    std::vector<std::vector<double>> dotMatrix{};
    std::vector<double> dotVector{};
    dotVector.push_back(dot);
    dotMatrix.push_back(dotVector);

    writeFile("vxv.txt", outer);
    writeFile("vdv.txt", dotMatrix);
    writeFile("vdvAvxv.txt", calc);

    return 0;
}