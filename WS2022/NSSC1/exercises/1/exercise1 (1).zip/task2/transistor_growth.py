import numpy as np
import matplotlib.pyplot as plt

Data = np.genfromtxt("CPU_analysis2.txt", dtype=None, delimiter=",")
years = [str(Data[i][0]) for i in range(len(Data))]
transistors = [Data[i][1] for i in range(len(Data))]

plt.bar(years, transistors, log=True)
plt.xlabel("years")
plt.ylabel("average transistor count")
plt.title("growth of the average transistor count per year")
plt.show()
