import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

data = pd.read_csv("CPU_analysis3.txt", names=["from_to","absolute_change","relative_change"])

fig, ax1 = plt.subplots()
ax2 = ax1.twinx()

width=0.3
x = np.arange(len(data["from_to"]))

a = ax1.bar(x-width/2, data["absolute_change"], width=width, log=True, color="orange", label="absolute change")
r = ax2.bar(x+width/2, data["relative_change"], width=width, log=True, color="green", label="relative change")

plots = [a,r]
labels = [l.get_label() for l in plots]
ax1.legend(plots, labels)

ax1.set_xlabel("years")
ax1.set_xticks(x)
ax1.set_xticklabels(data["from_to"])
ax1.set_ylabel("absolute growth of transistors")
ax2.set_ylabel("relative growth of transistors")
plt.title("absolute and relative growth of transistors")

plt.show()