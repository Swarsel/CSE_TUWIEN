#include <iostream>
#include <vector>
#include <chrono>
using namespace std;

// task c)
vector<int> matvecmul(vector<vector<int>> A,vector<int> v)
{
    int n = A[0].size();
    int m = A.size();
    // if (v.size() != n)
    // {
    //     cout << "Sizes of matrix and vector are not matching!" << endl;
    //     vector<int> error = {0};
    //     return error;
    // }
    vector<int> sol(m,0);
    for (int i = 0; i<m; i++)
    {
       for (int j = 0; j<n; j++)
       {
            sol[i] += A[i][j] * v[j];
       }
    }
    return sol;
}


int main()
{
    // task a) and b)
    int size = 5000;
    vector<vector<int>> A(size);
    vector<int> v(size);
    for (int i=0; i<size; i++)
    {
        v[i] = i+2;
        for (int j=0; j<size; j++) A[i].push_back((i+1)*j);
    }

    // task d)
    chrono::steady_clock::time_point t1 = chrono::steady_clock::now();
    vector<int> sol = matvecmul(A,v);
    chrono::steady_clock::time_point t2 = chrono::steady_clock::now();
    chrono::duration<double> time_span = chrono::duration_cast<chrono::duration<double>>(t2-t1);
    cout << "Calculation time: " << time_span.count() << " seconds" << endl;
    return 0;
}