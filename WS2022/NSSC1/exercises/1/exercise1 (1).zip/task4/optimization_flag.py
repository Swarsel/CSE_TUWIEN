import matplotlib.pyplot as plt
import numpy as np

times_O0=[0.272696,0.28839,0.28573,0.284594,0.286919,0.2983,0.287026,0.34167]
times_O1=[0.10483,0.114705,0.109746,0.0982765,0.104512,0.101689,0.0980045,0.10405]
times_O2=[0.0637573,0.0821013,0.0928001,0.0992423,0.078624,0.0710243,0.0685713,0.0728253]
times_O3=[0.0645424,0.073141,0.0727647,0.0711562,0.0738991,0.0736427,0.0709033,0.0768865]
times_funroll=[0.283453,0.27221,0.250901,0.288249,0.268424,0.271368,0.281938,0.32071]
times_funrollO3=[0.0754665,0.0640866,0.0620934,0.0576647,0.0733282,0.0594573,0.0689585,0.0607891]
times_fvectO3=[0.0811494,0.0647817,0.0631184,0.0598482,0.0734959,0.0767694,0.0654257,0.0725126]

averages = []
i=0
for list in [times_O0,times_O1,times_O2,times_O3,times_funroll,times_funrollO3,times_fvectO3]:
    averages.append(0.0)
    for time in list:
        averages[i] += time/8
    i+=1

x = np.arange(len(averages))
flags =["-O0","-O1","-O2","-O3","-funroll-loops","-funroll-loops -O3","-fvect-cost-model=very-cheap -O3"]
plt.bar(flags, averages, width=0.5)
plt.xlabel("flags")
plt.ylabel("average runtime in seconds")
plt.title("average runtimes of vector-matrix multplication with different compiler flags")
plt.show()

