#include <mpi.h> 
#include <array>
#include <chrono>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <limits>
#include <vector>

#include <assert.h>

template <typename Type> class MatrixView {
private:
  std::vector<Type> &v;
  MatrixView(const MatrixView &);
  MatrixView &operator=(const MatrixView &);

public:
  const size_t N, M;
  MatrixView(std::vector<Type> &v, size_t N, size_t M) : v(v), N(N), M(M) {
    assert(v.size() / N == M);
  }
  Type &set(size_t i, size_t j) { return v[i + N * j]; }
  const Type &get(size_t i, size_t j) { return v[i + N * j]; }
  Type &set(size_t n) { return v[n]; }
  const Type &get(size_t n) { return v[n]; }
};

double ParticularSolution(double x, double y) {
  return std::sin(2 * M_PI * x) * std::sinh(2 * M_PI * y);
}

double NormL2(const std::vector<double> &v) {
  double norm = 0;
  for (const auto &value : v) {
    norm += value * value;
  }
  return sqrt(norm);
}

double NormInf(const std::vector<double> &v) {
  double max = std::numeric_limits<double>::lowest();
  for (const auto &value : v) {
    max = std::fabs(value) > max ? std::fabs(value) : max;
  }
  return max;
}

struct Stencil {
  Stencil(double h)
      : C(4.0 / (h * h) + 4 * M_PI * M_PI), N(-1.0 / (h * h)),
        S(-1.0 / (h * h)), W(-1.0 / (h * h)), E(-1.0 / (h * h)) {}
  const double C, N, S, W, E;
};

enum Cell { UNKNOWN = 0, DIR = 1, NEU = 2, ROB = 0 };

void PoissonJacobiStencil(size_t resolution, size_t iterations, std::string dimension, int rank, int num_processes) {

  int ndims = 2;
  std::array<int, 2> dims = {0, 0};
  if (dimension=="1D") {
    dims[0] = num_processes;
    dims[1] = 1;
  }
  else if (dimension=="2D") {
    MPI_Dims_create(num_processes, ndims, std::data(dims));
  }
  else {
    std::cout << "wrong dimension argument" << std::endl;
    return;
  }
  
  if (rank==0) std::printf("cart size=(%i,%i)\n", dims[0], dims[1]);

  std::array<int, 2> periods = {false, false};
  int reorder = false;
  MPI_Comm comm_2d;
  MPI_Cart_create(MPI_COMM_WORLD, ndims, std::data(dims), std::data(periods),
                  reorder, &comm_2d);

  enum DIR : int { N = 0, S = 1, W = 2, E = 3 };
  std::array<int, 4> nb = {-1, -1, -1, -1};
  MPI_Cart_shift(comm_2d, 0, 1, &nb[DIR::S], &nb[DIR::N]);
  MPI_Cart_shift(comm_2d, 1, 1, &nb[DIR::W], &nb[DIR::E]);
  std::array<int, 2> coord = {-1, -1};
  MPI_Cart_coords(comm_2d, rank, ndims, std::data(coord));
  //std::printf("coord=(%i,%i)\n", coord[0], coord[1]);
  //std::printf("coord=(%i,%i,%i,%i)\n", nb[DIR::N], nb[DIR::S], nb[DIR::W], nb[DIR::E]);
  MPI_Barrier(MPI_COMM_WORLD);

  size_t Nu = resolution;
  size_t NY = Nu;
  size_t NX = Nu;
  double h = 1.0 / (Nu - 1);

  const auto stencil = Stencil(h);

  // domain cell types
  std::vector<int> domain(NX * NY, Cell::UNKNOWN);
  MatrixView<int> domainView(domain, NX, NY);
  for (size_t i = 0; i != NX; ++i) {
    domainView.set(i, 0) = Cell::DIR;
    domainView.set(i, NY - 1) = Cell::DIR;
  }
  for (size_t j = 0; j != NY; ++j) {
    domainView.set(0, j) = Cell::DIR;
    domainView.set(NX - 1, j) = Cell::DIR;
  }

  // referenceSolution
  std::vector<double> referenceSolution(NX * NY, 0);
  MatrixView<double> referenceSolutionView(referenceSolution, NX, NY);
  for (size_t j = 0; j != NY; ++j) {
    for (size_t i = 0; i != NX; ++i) {
      referenceSolutionView.set(i, j) = ParticularSolution(i * h, j * h);
    }
  }

  // right hand side
  std::vector<double> rightHandSide(NX * NY, 0);
  MatrixView<double> rightHandSideView(rightHandSide, NX, NY);
  for (size_t j = 0; j != NY; ++j) {
    for (size_t i = 0; i != NX; ++i) {
      rightHandSideView.set(i, j) =
          ParticularSolution(i * h, j * h) * 4 * M_PI * M_PI;
    }
  }

  auto SolverJacobi = [](std::vector<double> &sol, std::vector<double> &sol2,
                         std::vector<double> &rhs, const Stencil &stencil,
                         size_t NX, size_t NY, size_t start_Y, size_t end_Y, size_t start_X, size_t end_X) {
    MatrixView<double> solView(sol, NX, NY);
    MatrixView<double> sol2View(sol2, NX, NY);
    MatrixView<double> rhsView(rhs, NX, NY);
    for (size_t j = 1 + start_Y; j != end_Y; ++j) {
      for (size_t i = 1 + start_X; i != end_X; ++i) {
        sol2View.set(i, j) =
            1.0 / stencil.C *
            (rhsView.set(i, j) - (solView.get(i + 1, j) * stencil.E +
                                  solView.get(i - 1, j) * stencil.W +
                                  solView.get(i, j + 1) * stencil.S +
                                  solView.get(i, j - 1) * stencil.N));
      }
    }
    sol.swap(sol2);
    
  };

  auto ComputeResidual = [](std::vector<double> &sol, std::vector<double> &rhs,
                            const Stencil &stencil, size_t NX, size_t NY) {
    MatrixView<double> solView(sol, NX, NY);
    MatrixView<double> rhsView(rhs, NX, NY);

    std::vector<double> residual(NX * NY, 0);
    MatrixView<double> residualView(residual, NX, NY);
    for (size_t j = 1; j != NY - 1; ++j) {
      for (size_t i = 1; i != NX - 1; ++i) {
        residualView.set(i, j) =
            rhsView.get(i, j) -
            (solView.get(i, j) * stencil.C + solView.get(i + 1, j) * stencil.E +
             solView.get(i - 1, j) * stencil.W +
             solView.get(i, j - 1) * stencil.S +
             solView.get(i, j + 1) * stencil.N);
      }
    }
    return residual;
  };
  auto ComputeError = [](std::vector<double> &sol,
                         std::vector<double> &reference, size_t NX, size_t NY) {
    MatrixView<double> solView(sol, NX, NY);
    MatrixView<double> referenceView(reference, NX, NY);

    std::vector<double> error(NX * NY, 0);
    MatrixView<double> errorView(error, NX, NY);

    for (size_t j = 1; j != NY - 1; ++j) {
      for (size_t i = 1; i != NX - 1; ++i) {
        errorView.set(i, j) = referenceView.get(i, j) - solView.get(i, j);
      }
    }
    return error;
  };

  // solution approximation starting with boundary initialized to dirichlet
  // conditions, else 0
  std::vector<double> solution(NX * NY, 0);
  MatrixView<double> solutionView(solution, NX, NY);
  for (size_t j = 0; j != NY; ++j) {
    for (size_t i = 0; i != NX; ++i) {
      if (domainView.get(i, j) == Cell::DIR)
        solutionView.set(i, j) = ParticularSolution(i * h, j * h);
    }
  }
  
  std::vector<double> solution2 = solution;
  
  std::vector<int> width_Y(dims[0],NY / dims[0]);
  std::vector<int> start_Y(dims[0],0);
  std::vector<int> end_Y(dims[0],0);
  if (NY % dims[0] != 0) {
    for (int i=0; i != dims[0]; i++) {
      if (i >= int(dims[0] - NY % dims[0])) {
        width_Y[i]++;
      }
    }
  }
  int sum_Y=0;
  for (int i=0; i!= dims[0]; i++) {
    if (i!=0) sum_Y += width_Y[i-1];
    if (i!=0){
      start_Y[i] = sum_Y - 1;
    }
    else {
      start_Y[i] = 0;
    }
    if (i!=dims[0]-1) {
      end_Y[i] = sum_Y + width_Y[i];
    }
    else{
      if (dims[0]==1) end_Y[i] = start_Y[i] + width_Y[i] -1;
      else end_Y[i] = start_Y[i] + width_Y[i];
    }
  }

  std::vector<int> width_X(dims[1],NX / dims[1]);
  std::vector<int> start_X(dims[1],0);
  std::vector<int> end_X(dims[1],0);
  if (NX % dims[1] != 0) {
    for (int i=0; i != dims[1]; i++) {
      if (i >= int(dims[1] - NX % dims[1])) {
        width_X[i]++;
      }
    }
  }
  int sum_X=0;
  for (int i=0; i!= dims[1]; i++) {
    if (i!=0) sum_X += width_X[i-1];
    if (i!=0){
      start_X[i] = sum_X - 1;
    }
    else {
      start_X[i] = 0;
    }
    if (i!=dims[1]-1) {
      end_X[i] = sum_X + width_X[i];
    }
    else{
      if (dims[1]==1) end_X[i] = start_X[i] + width_X[i] -1;
      else end_X[i] = start_X[i] + width_X[i];
    }
  }

  std::cout << "solve LSE using stencil jacobi" << std::endl;
  auto start = std::chrono::high_resolution_clock::now();
  for (size_t iter = 0; iter <= iterations; ++iter) {
    SolverJacobi(solution, solution2, rightHandSide, stencil, NX, NY, start_Y[coord[0]], end_Y[coord[0]], start_X[coord[1]], end_X[coord[1]]);
    if (nb[DIR::N] >= 0) {
      MPI_Send(&solutionView.get(start_X[coord[1]]+1, end_Y[coord[0]]-1), width_X[coord[1]], MPI_DOUBLE, nb[DIR::N], 0, MPI_COMM_WORLD);
      MPI_Recv(&solutionView.set(start_X[coord[1]]+1,end_Y[coord[0]]), width_X[coord[1]], MPI_DOUBLE, nb[DIR::N], 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    }
    if (nb[DIR::S] >= 0) {
      MPI_Send(&solutionView.get(start_X[coord[1]]+1, start_Y[coord[0]]+1), width_X[coord[1]], MPI_DOUBLE, nb[DIR::S], 0, MPI_COMM_WORLD);
      MPI_Recv(&solutionView.set(start_X[coord[1]]+1, start_Y[coord[0]]), width_X[coord[1]], MPI_DOUBLE, nb[DIR::S], 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    }
    if (nb[DIR::W] >= 0) {
      std::vector<double> send_buffer(width_Y[coord[0]]);
      std::vector<double> recv_buffer(width_Y[coord[0]]);
      for (int i=0; i!= width_Y[coord[0]]; i++) {
        send_buffer[i] = solutionView.get(start_X[coord[1]]+1,start_Y[coord[0]]+1+i);
      }
      MPI_Send(&send_buffer[0], width_Y[coord[0]], MPI_DOUBLE, nb[DIR::W], 0, MPI_COMM_WORLD);
      MPI_Recv(&recv_buffer[0], width_Y[coord[0]], MPI_DOUBLE, nb[DIR::W], 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
      for (int i=0; i!= width_Y[coord[0]]; i++) {
        solutionView.set(start_X[coord[1]],start_Y[coord[0]]+1+i) = recv_buffer[i];
      }
    }
    if (nb[DIR::E] >= 0) {
      std::vector<double> send_buffer(width_Y[coord[0]]);
      std::vector<double> recv_buffer(width_Y[coord[0]]);
      for (int i=0; i!= width_Y[coord[0]]; i++) {
        send_buffer[i] = solutionView.get(end_X[coord[1]]-1,start_Y[coord[0]]+1+i);
      }
      MPI_Send(&send_buffer[0], width_Y[coord[0]], MPI_DOUBLE, nb[DIR::E], 0, MPI_COMM_WORLD);
      MPI_Recv(&recv_buffer[0], width_Y[coord[0]], MPI_DOUBLE, nb[DIR::E], 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
      for (int i=0; i!= width_Y[coord[0]]; i++) {
        solutionView.set(end_X[coord[1]],start_Y[coord[0]]+1+i) = recv_buffer[i];
      }
    }
  }
  MPI_Barrier(MPI_COMM_WORLD);
  if (rank==0) {
    auto stop = std::chrono::high_resolution_clock::now();
    auto seconds =
        std::chrono::duration_cast<std::chrono::duration<double>>(stop - start)
            .count();
    std::cout << std::scientific << "average runtime per iteration =" << seconds/iterations << std::endl;
  }

  if (rank != 0) {
    int edgeX = 0;
    int edgeY = 0;
    if (dims[1]-1==0) edgeX = 2;
    else if ((coord[1]==0)||(coord[1]==dims[1]-1)) edgeX = 1;
    if (dims[0]-1==0) edgeY = 2;
    else if ((coord[0]==0)||(coord[0]==dims[0]-1)) edgeY = 1;
    int size = (width_X[coord[1]]-edgeX) * (width_Y[coord[0]]-edgeY);
    std::vector<double> buffer(size,0.0);
    MatrixView<double> bufferView(buffer, (width_X[coord[1]]-edgeX), (width_Y[coord[0]]-edgeY));
    for (int j = 0; j !=(width_Y[coord[0]]-edgeY); j++) {
      for (int i = 0; i !=(width_X[coord[1]]-edgeX); i++) {
        bufferView.set(i,j) = solutionView.set(start_X[coord[1]]+1+i,start_Y[coord[0]]+1+j);
      }
    }
    MPI_Send(&buffer[0], size, MPI_DOUBLE, 0, rank, MPI_COMM_WORLD);
  }
  if (rank == 0) {
    for (int i = 0; i != dims[0]; i++) {
      for (int j = 0; j != dims[1]; j++) {
        if (!((i==coord[0])&&(j==coord[1]))) {
          int coords[2] = {i,j};
          int recv_rank;
          MPI_Cart_rank(comm_2d, coords, &recv_rank);
          int edgeX = 0;
          int edgeY = 0;
          if (dims[1]-1==0) edgeX = 2;
          else if ((coords[1]==0)||(coords[1]==dims[1]-1)) edgeX = 1;
          if (dims[0]-1==0) edgeY = 2;
          else if ((coords[0]==0)||(coords[0]==dims[0]-1)) edgeY = 1;
          int size = (width_X[coords[1]]-edgeX) * (width_Y[coords[0]]-edgeY);
          std::vector<double> buffer(size,0.0);
          MatrixView<double> bufferView(buffer, (width_X[coords[1]]-edgeX), (width_Y[coords[0]]-edgeY));
          MPI_Recv(&buffer[0], size,  MPI_DOUBLE, recv_rank, recv_rank, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
          for (int j = 0; j !=(width_Y[coords[0]]-edgeY); j++) {
            for (int i = 0; i !=(width_X[coords[1]]-edgeX); i++) {
              solutionView.set(start_X[coords[1]]+1+i,start_Y[coords[0]]+1+j) = bufferView.set(i,j);
            }
          }
        }
      }
    }
  }

 
  if (rank==0) {
    
    auto residual = ComputeResidual(solution, rightHandSide, stencil, NX, NY);
    auto residualNorm = NormL2(residual);
    std::cout << std::scientific << "|residual|=" << residualNorm << std::endl;
    auto residualMax = NormInf(residual);
    std::cout << std::scientific << "|residualMax|=" << residualMax
              << std::endl;
    auto error = ComputeError(solution, referenceSolution, NX, NY);
    auto errorNorm = NormL2(error);
    std::cout << std::scientific << "|error|=" << errorNorm << std::endl;
    auto errorMax = NormInf(error);
    std::cout << std::scientific << "|errorMax|=" << errorMax << std::endl;
    
  }
}
