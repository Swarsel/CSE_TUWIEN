#include <assert.h>
#include <iomanip>
#include <iostream>
#include <vector>
#include <mpi.h> 

#include "arguments.hpp"
#include "solver_2D.hpp"

int main(int argc, char **argv) {

  // parse command line arguments
  auto dimension = argv[1];
  auto resolution = convertTo<int>(2, 32, argc, argv);
  auto iterations = convertTo<int>(3, 800, argc, argv);

  assert(resolution > 0);
  assert(iterations > 0);


  MPI_Init(&argc, &argv);
  

  int rank;
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  int num_processes;
  MPI_Comm_size(MPI_COMM_WORLD, &num_processes);

  if (rank == 0) {
    std::cout << "resolution=" << resolution << std::endl;
    std::cout << "iterations=" << iterations << std::endl;
    std::cout << "###" << std::endl;
    std::cout << "total number of MPI processes=" << num_processes << ":"
              << std::endl;
  }
  MPI_Barrier(MPI_COMM_WORLD);
  PoissonJacobiStencil(resolution, iterations, dimension, rank, num_processes);

  MPI_Barrier(MPI_COMM_WORLD);
  MPI_Finalize();

  return 0;
}
