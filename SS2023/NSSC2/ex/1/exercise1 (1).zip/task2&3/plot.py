import matplotlib.pyplot as plt


runs = []
file1 = open('stdout-jacobiMPI.86620.log', 'r')
Lines = file1.readlines()
for line in Lines:
    if line[0:7] == "runtime":
        runs.append(float(line[8:]))

resolution = [125,250,1000,2000]
num_processes = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,25,30,35,40]

runtimes_MPI = [runs[0:24],runs[24:48],runs[48:72],runs[72:]]
for i in range(len(resolution)):
    for j in range(len(num_processes)):
        print("resolution: ", resolution[i], "num_processes: ", num_processes[j], "runtime: ", runtimes_MPI[i][j])

runtimes_serial = [7.291951e-02,4.530244e-01,1.289793e+01,6.625635e+01]

speedup = [[runtimes_serial[i]/runtimes_MPI[i][j] for j in range(len(num_processes))] for i in range(len(resolution))]
efficiency = [[runtimes_serial[i]/runtimes_MPI[i][j]/num_processes[j] for j in range(len(num_processes))] for i in range(len(resolution))]

plt.subplot(121)
for i in range(len(resolution)):
    plt.plot(num_processes,speedup[i],label="resolution: " + str(resolution[i]))
plt.plot(num_processes,num_processes, "--", label="ideal")
plt.legend()
plt.xlabel("number of processors")
plt.ylabel("speedup")
plt.title("speedup")

plt.subplot(122)
for i in range(len(resolution)):
    plt.plot(num_processes,efficiency[i],label="resolution: " + str(resolution[i]))
plt.plot(num_processes,[1 for i in range(len(num_processes))], "--", label="ideal")
plt.legend()
plt.xlabel("number of processors")
plt.ylabel("efficiency")
plt.title("efficiency")

plt.show()
