#!/bin/bash

## job name

#SBATCH --job-name=jacobiMPI

## logfiles (stdout/stderr) %x=job-name %j=job-id

#SBATCH --output=stdout-%x.%j.log
#SBATCH --error=stderr-%x.%j.log

## resource requests 

#SBATCH --partition=nssc    # partition for 360.242 and 360.242
#SBATCH --nodes=1           # number of nodes
#SBATCH --ntasks=40          # number of processes
#SBATCH --cpus-per-task=1   # number of cpus per process
#SBATCH --time=10:00:00     # set time limit to 10 hours

## load modules and compilation (still on the login node)

module load pmi/pmix-x86_64     # [P]rocess [M]anagement [I]nterface (required by MPI-Implementation)
module load mpi/openmpi-x86_64  # MPI implementation (including compiler-wrappers mpicc/mpic++)

mpic++ -std=c++17 -O3 -Wall -pedantic -march=native -ffast-math main.cpp -o jacobiMPI

## submitting jobs (on the allocated resources)

# job: run the mpi-enabled executable passing command line arguments

for resolution in {125,250,1000,2000}
do
    for n in {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,25,30,35,40}
    do
        srun --mpi=pmix --ntasks=${n} ./jacobiMPI 1D ${resolution} 10000
    done
done
