#include <iostream>

int main() {

  std::cout << "printing to stdout." << std::endl;
  std::cerr << "printing to stderr." << std::endl;

  return 0;
}
