import numpy as np
import matplotlib.pyplot as plt
from time import time
import argparse


def gauss(x):
    return np.exp(-10 * (4 * x - 1) ** 2)


def square(x):
    return np.array([1 if 0.1 < xi < 0.3 else 0 for xi in x])


def solve_numeric(f, x, Co, steps, dx):
    C = f(x)
    out = [C]
    for _ in range(steps - 1):
        # perform upwind step accoring to p.73
        Cp = []
        for i in range(len(C)):
            Cp.append((1 - Co) * C[i] + Co * C[i - 1])
        C = Cp  # reference copy is enough here since we dont edit Cp until having used C, and its faster
        out.append(C)
    return np.array(out)


def solve_analytic(f, x, steps, dt, U=1):
    ts = [dt * t for t in range(steps)]
    return [f((x - U * t) % 1) for t in ts]  # use cyclic boundary conditions


def get_frame(i, f, name, Co, dx=0.01, dt=0.01, steps=1000):
    x = np.arange(0, 1, dx)

    num = solve_numeric(f, x, Co, steps, dx)
    ana = solve_analytic(f, x, steps, dt, U=Co * dx / dt)  # Co = U * dt / dx
    error = [abs(n - a) for n, a in zip(num, ana)]

    plt.plot(x, num[i], label="Numeric solution")
    plt.plot(x, ana[i], ".", label="Analytic solution")
    plt.plot(x, error[i], label="Absolute error")
    plt.plot(x, num[0], "--", label="Initial condition")

    plt.title(f"{name.capitalize()}, Co={Co}, Step {i}")
    plt.ylim([-0.25, 1.5])
    plt.legend(loc="upper left")
    plt.grid()
    plt.savefig(f"frames/{name}_co={Co}_dx={dx}_dt={dt}_steps={steps}_frame{frame}.png")
    plt.show()
    plt.close()


if __name__ == "__main__":

    CLI = argparse.ArgumentParser()
    CLI.add_argument(
        "--dx",
        type=float,
        default=0.01
    )
    CLI.add_argument(
        "--dt",
        type=float,
        default=0.01
    )
    CLI.add_argument(
        "--steps",
        type=int,
        default=1000
    )
    CLI.add_argument(
        "--Co",
        nargs="*",
        type=float,
        default=[0.8, 1, 1.01, 1.05, 1.1]
    )
    CLI.add_argument(
        "--f",
        type=str,
        default="square"
    )

    args = CLI.parse_args()
    func_list = [gauss, square]
    func_names = [f.__name__ for f in func_list]
    funcs_dict = dict(zip(func_names, func_list))
    while True:
        try:
            frame = int(input("Capture which frame?"))
        except ValueError as msg:
            print(msg)
        for co in args.Co:
            try:
                print(f"Capturing {args.f}, Co={co}, frame {frame} ...", end="")
                start = time()
                get_frame(frame, funcs_dict[args.f], args.f, co, dx=args.dx, dt=args.dt, steps=args.steps)
                end = time()
                print(f"done, took {end - start}s")
            except NameError as msg:
                print(msg)

