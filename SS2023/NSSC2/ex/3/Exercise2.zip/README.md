# /frames
- Contains snapshots of single frames created by Task2Frame.py

# /movies
- Contains .gifs created by Task2.py

# Task2.py
- solves the given 1D advection equation using the upwind scheme and compares the solution to the analytic solution
- the given gauss signal and square pulse where implemented for this
- usage: Task2.py --dx [float] --dt [float] --steps [int] --Co [array[float]] 
- example: Task2.py --dx 0.01 --dt 0.01 --steps 200 --Co 0.8 1 1.1

# Task2Frame.py
- creates snapshots for a given initial condition and frame for a range of courant numbers
- usage: Task2.py --dx [float] --dt [float] --steps [int] --Co [array[float]] --f [str (either "gauss" or "square")]
- example: Task2.py --dx 0.01 --dt 0.01 --steps 200 --Co 0.8 1 1.1 --f gauss

