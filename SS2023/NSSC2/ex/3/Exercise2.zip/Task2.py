import numpy as np
import matplotlib.pyplot as plt
from time import time
from matplotlib.animation import FuncAnimation
import argparse


def gauss(x):
    return np.exp(-10 * (4 * x - 1) ** 2)


def square(x):
    return np.array([1 if 0.1 < xi < 0.3 else 0 for xi in x])


def solve_numeric(f, x, Co, steps):
    C = f(x)
    out = [C]
    for _ in range(steps - 1):
        # perform upwind step accoring to p.73
        Cp = []
        for i in range(len(C)):
            Cp.append((1 - Co) * C[i] + Co * C[i - 1])
        C = Cp  # reference copy is enough here since we dont edit Cp until having used C, and its faster
        out.append(C)
    return np.array(out)


def solve_analytic(f, x, steps, dt, U=1):
    ts = [dt * t for t in range(steps)]
    return [f((x - U * t) % 1) for t in ts]  # use cyclic boundary conditions


def movie(f, name, Co, dx=0.01, dt=0.01, steps=1000):
    x = np.arange(0, 1, dx)

    num = solve_numeric(f, x, Co, steps)
    ana = solve_analytic(f, x, steps, dt, U=Co * dx / dt)  # Co = U * dt / dx
    error = [abs(n - a) for n, a in zip(num, ana)]

    # More on FuncAnimation: https://jakevdp.github.io/blog/2012/08/18/matplotlib-animation-tutorial/
    fig, ax = plt.subplots()

    # initial frame
    line1, = ax.plot(x, num[0], label="Numeric solution")
    line2, = ax.plot(x, ana[0], ".", label="Analytic solution")
    line3, = ax.plot(x, error[0], label="Absolute error")
    line4, = ax.plot(x, num[0], "--", label="Initial condition")

    ax.set_title(f"{name.capitalize()},Co={Co}, Step 0")
    ax.set_ylim([-0.25, 1.5])
    ax.legend(loc="upper left")
    ax.grid()

    def _animate(i):
        ax.set_title(f"{name.capitalize()},Co={Co}, Step {i + 1}")
        line1.set_ydata(num[i])
        line2.set_ydata(ana[i])
        line3.set_ydata(error[i])

    anim = FuncAnimation(fig, _animate, frames=len(num))
    anim.save(f"movies/{name}_co={Co}_dx={dx}_dt={dt}_steps={steps}.gif", fps=30)


if __name__ == "__main__":

    CLI = argparse.ArgumentParser()
    CLI.add_argument(
        "--dx",
        type=float,
        default=0.01
    )
    CLI.add_argument(
        "--dt",
        type=float,
        default=0.01
    )
    CLI.add_argument(
        "--steps",
        type=int,
        default=1000
    )
    CLI.add_argument(
        "--Co",
        nargs="*",
        type=float,
        default=[0.8, 1, 1.01, 1.05, 1.1]
    )

    args = CLI.parse_args()
    for init, funcname in zip([gauss, square], ["gauss", "square"]):
        for co in args.Co:
            print(f"Running {funcname}, Co={co} ...", end="")
            start = time()
            movie(init, funcname, co, dx=args.dx, dt=args.dt, steps=args.steps)
            end = time()
            print(f"done, took {end - start}s")

