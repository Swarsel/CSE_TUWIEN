import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import copy

# Spatial parameters
nx = 100
ny = 100
Lx = 1
Ly = 1
dx = Lx/(nx-1)
dy = Ly/(ny-1)

# Other parameters
U = 1
Re = 1000
Pr = 1
dt = 0.001
numTimeSteps = 100000

# Initialization
psi = np.zeros((nx, nx))
psin = np.zeros((nx, nx))
vor = np.zeros((nx,nx))
vorn = np.zeros((nx,nx))
ut = np.zeros((nx,nx))
ut[-1,:] = U
vt = np.zeros((nx,nx))
u = [ut]
v=[vt]
Ct = np.zeros((nx,nx))
Ct[:,0] = 1
C = []
C.append(Ct)
it = 0
eps = 10e-07
# Loop over timesteps
for _ in range(numTimeSteps):
    it +=1
    # Numerical solution of poisson
    err = 1

    # Solve poisson with guass-seidel
    while err > 10e-07:
        psin[1:-1,1:-1] = (dy * dy * vor[1:-1, 1:-1] + psi[0:-2,1:-1] + psi[2:,1:-1] + psi[1:-1, 0:-2] + psi[1:-1,2:])/4.0
        err = np.linalg.norm(psin - psi)
        psi = copy.deepcopy(psin)
    
    # Implement boundary conditions
    vor[:,0] = -(8*psi[:,1] - psi[:,2]) / 2.0 / dx / dx
    vor[:,-1] = -(8*psi[:,-2] - psi[:,-3]) / 2.0 / dx / dx

    vor[0,:] = -(8*psi[1,:] - psi[2,:]) / 2.0 / dy / dy
    vor[-1,:] =- (8*psi[-2,:] - psi[-3,:]) / 2.0 / dy / dy - 3*U / dy

    # Compute vorticity
    dpsidy = (psi[2:,1:-1] - psi[0:-2,1:-1])/2.0/dy
    dpsidx = (psi[1:-1,2:] - psi[1:-1,0:-2])/2.0/dx
    dvordy = (vor[2:,1:-1] - vor[0:-2,1:-1])/2.0/dy
    dvordx = (vor[1:-1,2:] - vor[1:-1,0:-2])/2.0/dx
    
    dvor2dx2 = (vor[1:-1,0:-2] - 2.0*vor[1:-1,1:-1] + vor[1:-1,2:])/dx/dx
    dvor2dy2 = (vor[0:-2,1:-1] - 2.0*vor[1:-1,1:-1] + vor[2:,1:-1])/dy/dy
    
    vorn[1:-1,1:-1] = vor[1:-1,1:-1] + dt*(-dpsidy * dvordx + dpsidx * dvordy) + dt/Re * (dvor2dx2 + dvor2dy2)

    # Store velocities
    ut[1:-1,1:-1] = dpsidy
    vt[1:-1,1:-1] = -dpsidx
    u.append(ut.copy())
    v.append(vt.copy())

    # Compute scalar concentration
    dCdy = (C[-1][2:,1:-1] - C[-1][0:-2,1:-1])/2.0/dy
    dCdx = (C[-1][1:-1,2:] - C[-1][1:-1,0:-2])/2.0/dx
    dC2dx2 = (C[-1][1:-1,0:-2] - 2.0*C[-1][1:-1,1:-1] + C[-1][1:-1,2:])/dx/dx
    dC2dy2 = (C[-1][0:-2,1:-1] - 2.0*C[-1][1:-1,1:-1] + C[-1][2:,1:-1])/dy/dy
    Ct[1:-1,1:-1] = C[-1][1:-1,1:-1] + dt*(-dpsidy * dCdx + dpsidx * dCdy) + dt/Re/Pr * (dC2dx2 + dC2dy2)

    # upper boundary
    dCdx = (C[-1][-1,2:] - C[-1][-1,0:-2])/2.0/dx
    dpsidx = (psi[-1,2:] - psi[-1,0:-2])/2.0/dx
    dC2dx2 = (C[-1][-1,0:-2] - 2.0*C[-1][-1,1:-1] + C[-1][-1,2:])/dx/dx
    dC2dy2 = (-2.0*C[-1][-1,1:-1] + 2*C[-1][-2,1:-1])/dy/dy
    Ct[-1,1:-1] = C[-1][-1,1:-1] + dt*(-U*dCdx) + dt/Re/Pr * (dC2dx2 + dC2dy2)

    # east boundary
    dC2dx2 = (-2.0*C[-1][1:-1,-1] + 2*C[-1][1:-1,-2])/dx/dx
    dC2dy2 = (C[-1][0:-2,-1] - 2.0*C[-1][1:-1,-1] + C[-1][2:,-1])/dy/dy
    Ct[1:-1,-1] = C[-1][1:-1,-1] + dt/Re/Pr * (dC2dx2 + dC2dy2)

    # lower boundary
    dC2dx2 = (C[-1][0,0:-2] - 2.0*C[-1][0,1:-1] + C[-1][0,2:])/dx/dx
    dC2dy2 = (-2.0*C[-1][0,1:-1] + 2*C[-1][1,1:-1])/dy/dy
    Ct[0,1:-1] = C[-1][0,1:-1] + dt/Re/Pr * (dC2dx2 + dC2dy2)

    # top right corner
    dC2dx2 = (-2.0*C[-1][-1,-1] + 2*C[-1][-1,-2])/dx/dx
    dC2dy2 = (-2.0*C[-1][-1,-1] + 2*C[-1][-2,-1])/dy/dy
    Ct[-1,-1] = C[-1][-1,-1] + dt/Re/Pr * (dC2dx2 + dC2dy2)

    # bottom right corner
    dC2dx2 = (-2.0*C[-1][0,-1] + 2*C[-1][0,-2])/dx/dx
    dC2dy2 = (-2.0*C[-1][0,-1] + 2*C[-1][1,-1])/dy/dy
    Ct[0,-1] = C[-1][0,-1] + dt/Re/Pr * (dC2dx2 + dC2dy2)

    C.append(Ct.copy())
 
   
    # Compute max error of vorticity
    err = np.max(np.abs(vor[1:-1,1:-1] - vorn[1:-1,1:-1]))
    vor = copy.deepcopy(vorn)
    # Print error every 100 iterations
    if it%100 == 0:
        print(f"Iter: {it}, Error: {err}")
    
    # Stop if steady state solution reached
    if err < eps:
        break

# Streamplot
x = np.linspace(0, 1, nx)
y = np.linspace(0, 1, ny)
X,Y = np.meshgrid(x, y)

fig, ax = plt.subplots()
stream = ax.streamplot(X,Y,u[-1], v[-1],density=2, cmap='jet',arrowsize=1)
ax.set_xlabel('x')
ax.set_ylabel('y')
ax.set_title(f'Streamplot Re={Re}')
ax.set_xlim([0,Lx])
ax.set_ylim([0,Ly])
#plt.savefig(f"Streamplot Re={Re}.png")
plt.show()

fig, ax = plt.subplots()
stream = ax.contourf(X,Y,psi,cmap='plasma')
ax.set_xlabel('x')
ax.set_ylabel('y')
ax.set_xlim([0,Lx])
ax.set_ylim([0,Ly])
ax.set_title(f'Streamfunction Re={Re}')
cbar = fig.colorbar(stream)
cbar.ax.set_ylabel('Stream function')
#plt.savefig(f"Streamfunction Re={Re}.png")
plt.show()


# Animation
Cani = C[0:-1:50]

fig, ax = plt.subplots()
ax.set_xlabel('x')
ax.set_ylabel('y')
ax.set_title(f'Scalar concentration Re={Re}')
ax.set_xlim([0,Lx])
ax.set_ylim([0,Ly])
def animate(i):
    ax.clear()
    ax.set_xlabel('x')
    ax.set_ylabel('y')
    ax.set_title(f'Scalar concentration Re={Re}')
    ax.set_xlim([0,Lx])
    ax.set_ylim([0,Ly])
    ax.contourf(X,Y,Cani[i], cmap='plasma')

# Call animate method
ani = animation.FuncAnimation(fig, animate, frames=len(Cani), interval=1, blit=False)

# Display the plot
plt.show()
#writervideo = animation.FFMpegWriter(fps=60)
#ani.save(f'scalarconc_Re{Re}.mp4', writer=writervideo)
