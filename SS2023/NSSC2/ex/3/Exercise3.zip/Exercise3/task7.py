import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import copy

# Note: In comparison to task6.py some code is commented out to reduce required RAM

# Spatial parameters
nx = 100
ny = 100
Lx = 1
Ly = 1
dx = Lx/(nx-1)
dy = Ly/(ny-1)

omega = 3/4
U = lambda t: np.sin(omega*t)
Re = 2000
Pr = 1
dt = 0.001
numTimeSteps = 150000

# Initialization
psi = np.zeros((nx, nx))
psin = np.zeros((nx, nx))
vor = np.zeros((nx,nx))
vorn = np.zeros((nx,nx))
ut = np.zeros((nx,nx))
ut[-1,:] = U(0)
vt = np.zeros((nx,nx))
u = [ut]
v=[vt]
Ct = np.zeros((nx,nx))
Ct[:,0] = 1
C = [Ct]
it = 0
eps = 10e-07
for _ in range(numTimeSteps):
    it +=1
    # Numerical solution of poisson
    err = 1
    while err > 10e-07:
        psin[1:-1,1:-1] = (dy * dy * vor[1:-1, 1:-1] + psi[0:-2,1:-1] + psi[2:,1:-1] + psi[1:-1, 0:-2] + psi[1:-1,2:])/4.0
        err = np.linalg.norm(psin - psi)
        psi = copy.deepcopy(psin)

    # Apply BC
    vor[:,0] = -(8*psi[:,1] - psi[:,2]) / 2.0 / dx / dx
    vor[:,-1] = -(8*psi[:,-2] - psi[:,-3]) / 2.0 / dx / dx

    vor[0,:] = -(8*psi[1,:] - psi[2,:]) / 2.0 / dy / dy
    vor[-1,:] =- (8*psi[-2,:] - psi[-3,:]) / 2.0 / dy / dy - 3*U(dt*(numTimeSteps+1)) / dy

    # Compute vorticity
    dpsidy = (psi[2:,1:-1] - psi[0:-2,1:-1])/2.0/dy
    dpsidx = (psi[1:-1,2:] - psi[1:-1,0:-2])/2.0/dx
    dvordy = (vor[2:,1:-1] - vor[0:-2,1:-1])/2.0/dy
    dvordx = (vor[1:-1,2:] - vor[1:-1,0:-2])/2.0/dx
    
    dvor2dx2 = (vor[1:-1,0:-2] - 2.0*vor[1:-1,1:-1] + vor[1:-1,2:])/dx/dx
    dvor2dy2 = (vor[0:-2,1:-1] - 2.0*vor[1:-1,1:-1] + vor[2:,1:-1])/dy/dy
    
    vorn[1:-1,1:-1] = vor[1:-1,1:-1] + dt*(-dpsidy * dvordx + dpsidx * dvordy) + dt/Re * (dvor2dx2 + dvor2dy2)

    #ut[-1,:] = U(dt*(numTimeSteps+1))
    #ut[1:-1,1:-1] = dpsidy
    #vt[1:-1,1:-1] = -dpsidx
    #u.append(ut.copy())
    #v.append(vt.copy())

    # Compute scalar concentration
    dCdy = (C[-1][2:,1:-1] - C[-1][0:-2,1:-1])/2.0/dy
    dCdx = (C[-1][1:-1,2:] - C[-1][1:-1,0:-2])/2.0/dx
    dC2dx2 = (C[-1][1:-1,0:-2] - 2.0*C[-1][1:-1,1:-1] + C[-1][1:-1,2:])/dx/dx
    dC2dy2 = (C[-1][0:-2,1:-1] - 2.0*C[-1][1:-1,1:-1] + C[-1][2:,1:-1])/dy/dy
    Ct[1:-1,1:-1] = C[-1][1:-1,1:-1] + dt*(-dpsidy * dCdx + dpsidx * dCdy) + dt/Re/Pr * (dC2dx2 + dC2dy2)

    # upper boundary
    dCdx = (C[-1][-1,2:] - C[-1][-1,0:-2])/2.0/dx
    dpsidx = (psi[-1,2:] - psi[-1,0:-2])/2.0/dx
    dC2dx2 = (C[-1][-1,0:-2] - 2.0*C[-1][-1,1:-1] + C[-1][-1,2:])/dx/dx
    dC2dy2 = (-2.0*C[-1][-1,1:-1] + 2*C[-1][-2,1:-1])/dy/dy
    Ct[-1,1:-1] = C[-1][-1,1:-1] + dt*(-U(dt*(numTimeSteps+1))*dCdx) + dt/Re/Pr * (dC2dx2 + dC2dy2)

    # east boundary
    dC2dx2 = (-2.0*C[-1][1:-1,-1] + 2*C[-1][1:-1,-2])/dx/dx
    dC2dy2 = (C[-1][0:-2,-1] - 2.0*C[-1][1:-1,-1] + C[-1][2:,-1])/dy/dy
    Ct[1:-1,-1] = C[-1][1:-1,-1] + dt/Re/Pr * (dC2dx2 + dC2dy2)

    # lower boundary
    dC2dx2 = (C[-1][0,0:-2] - 2.0*C[-1][0,1:-1] + C[-1][0,2:])/dx/dx
    dC2dy2 = (-2.0*C[-1][0,1:-1] + 2*C[-1][1,1:-1])/dy/dy
    Ct[0,1:-1] = C[-1][0,1:-1] + dt/Re/Pr * (dC2dx2 + dC2dy2)

    # top right corner
    dC2dx2 = (-2.0*C[-1][-1,-1] + 2*C[-1][-1,-2])/dx/dx
    dC2dy2 = (-2.0*C[-1][-1,-1] + 2*C[-1][-2,-1])/dy/dy
    Ct[-1,-1] = C[-1][-1,-1] + dt/Re/Pr * (dC2dx2 + dC2dy2)

    # bottom right corner
    dC2dx2 = (-2.0*C[-1][0,-1] + 2*C[-1][0,-2])/dx/dx
    dC2dy2 = (-2.0*C[-1][0,-1] + 2*C[-1][1,-1])/dy/dy
    Ct[0,-1] = C[-1][0,-1] + dt/Re/Pr * (dC2dx2 + dC2dy2)
    C.append(Ct.copy())
   
    err = np.max(np.abs(vor[1:-1,1:-1] - vorn[1:-1,1:-1]))
    vor = copy.deepcopy(vorn)
    if it%100 == 0:
        print(it, err)
    if err < eps:
        break

# Streamplot
x = np.linspace(0, Lx, nx)
y = np.linspace(0, Ly, ny)
X,Y = np.meshgrid(x, y)

#fig, ax = plt.subplots()
#stream = ax.streamplot(X,Y,u[-1], v[-1],density=2, cmap='jet',arrowsize=1)
#ax.set_xlabel('x')
#ax.set_ylabel('y')
#ax.set_title(f'TDBC Streamplot Re={Re}')
#ax.set_xlim([0,Lx])
#ax.set_ylim([0,Ly])
#plt.savefig(f"TDBC Streamplot Re={Re}.png")
#plt.show()

fig, ax = plt.subplots()
stream = ax.contourf(X,Y,psi,cmap='plasma')
ax.set_xlabel('x')
ax.set_ylabel('y')
ax.set_xlim([0,Lx])
ax.set_ylim([0,Ly])
ax.set_title(f'TDBC Streamfunction Re={Re}')
cbar = fig.colorbar(stream)
cbar.ax.set_ylabel('Stream function')
#plt.savefig(f"TDBC Streamfunction Re={Re}.png")
plt.show()


# Animation
Cani = C[0:-1:50]

fig, ax = plt.subplots()
ax.set_xlabel('x')
ax.set_ylabel('y')
ax.set_title(f'TDBP Scalar concentration Re={Re} w={omega:.2f}')
ax.set_xlim([0,Lx])
ax.set_ylim([0,Ly])
def animate(i):
    ax.clear()
    ax.set_xlabel('x')
    ax.set_ylabel('y')
    ax.set_title(f'TDBP Scalar concentration Re={Re} w={omega:.2f}')
    ax.set_xlim([0,Lx])
    ax.set_ylim([0,Ly])
    ax.contourf(X,Y,Cani[i], cmap='plasma')

# Call animate method
ani = animation.FuncAnimation(fig, animate, frames=len(Cani), interval=1, blit=False)

# Display the plot
plt.show()
#writervideo = animation.FFMpegWriter(fps=60)
#ani.save(f'scalarconcperbc_Re{Re}.mp4', writer=writervideo)