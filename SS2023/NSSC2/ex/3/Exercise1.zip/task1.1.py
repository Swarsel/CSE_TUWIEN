from matplotlib import pyplot as plt
import numpy as np
from matplotlib.animation import FuncAnimation

D = 1e-6
h = 1.0
Nx = 100
Nt = 2000
dx = h/Nx
dt = 0.5 * dx*dx/D
C = np.zeros(Nx)
C_analy = np.zeros(Nx)
print("dx = ", dx, "dt = ", dt)

# dirichlet boundary conditions
C[0] = 1.0
Ct = [np.array(C)]

# analytical solution
x = np.linspace(0,h*h,Nx)


def C_a(t):
    c = 0
    for n in range(1000):
        npi = (n+0.5)*np.pi
        inc = np.cos(npi*x) * np.exp(-npi**2*t) / npi
        if (n % 2) == 0:
            c += inc
        else:
            c -= inc
    return 1 - 2*c


# x and t are rescaled to dimensionless form
Ct_analy = []
for t in range(Nt):
    Ct_analy.append(np.flip(C_a(D/(h*h)*t*dt)))


print("analytical solution done")
factor = D * dt/(dx*dx)
for n in range(Nt-1):
    C[1:-1] += factor * (C[0:-2] - 2 * C[1:-1] + C[2:])
    # von neumann boundary conditions
    C[-1] += factor * (2 * C[-2] - 2 * C[-1])
    Ct.append(np.array(C))


x = np.linspace(0,h,Nx)
fig = plt.figure()
axis = plt.axes(xlim=(0, h), ylim=(0, 1))

line1, = axis.plot(x, Ct[0], label="numerical solution")
line2, = axis.plot(x, Ct_analy[0], ".", label="analytical solution")
axis.legend()
axis.set_xlabel("x")
axis.set_ylabel("C")


def animate(i):
    line1.set_ydata(Ct[i])
    line2.set_ydata(Ct_analy[i])


anim = FuncAnimation(fig, animate, frames=Nt)
anim.save('1_1.mp4', writer='ffmpeg', fps=30)
plt.show()
