from matplotlib import pyplot as plt
import numpy as np
from matplotlib.animation import FuncAnimation

D = 1e-6
h = 1.0
Nx = 100
Nt = 2000
dx = h/Nx
dt = 2 * dx*dx/D
C_old = np.zeros(Nx)
C_new = np.zeros(Nx)
C_analy = np.zeros(Nx)
print("dx = ", dx, "dt = ", dt)

s = dt/(dx*dx)*D
main = np.full(Nx,1+2*s)
off = np.full(Nx-1,-s)
tri = np.diag(main,k=0) + np.diag(off,k=-1) + np.diag(off,k=1)
tri[0,0] = 1
tri[0,1] = 0
# dirichlet boundary conditions
C_old[0] = 1.0
# von neumann boundary conditions
tri[-1,-2] *= 2
Ct = [np.array(C_old)]

# analytical solution
x = np.linspace(0,h*h,Nx)


def C_a(t):
    c = 0
    for n in range(1000):
        npi = (n+0.5)*np.pi
        inc = np.cos(npi*x) * np.exp(-npi**2*t) / npi
        if (n % 2) == 0:
            c += inc
        else:
            c -= inc
    return 1 - 2*c

# x and t are rescaled to dimensionless form
Ct_analy = []
for t in range(Nt):
    Ct_analy.append(np.flip(C_a(D/(h*h)*t*dt)))


print("analytical solution done")

for n in range(Nt-1):
    C_new = np.linalg.solve(tri, C_old)
    Ct.append(np.array(C_new))
    C_old = C_new


x = np.linspace(0,h,Nx)
fig = plt.figure()
axis = plt.axes(xlim=(0, h), ylim=(0, 1))

line1, = axis.plot(x, Ct[0], label="numerical solution")
line2, = axis.plot(x, Ct_analy[0], ".", label="analytical solution")
axis.legend()
axis.set_xlabel("x")
axis.set_ylabel("C")


def animate(i):
    line1.set_ydata(Ct[i])
    line2.set_ydata(Ct_analy[i])


anim = FuncAnimation(fig, animate, frames=Nt)
anim.save('1_3.mp4', writer='ffmpeg', fps=30)
plt.show()
