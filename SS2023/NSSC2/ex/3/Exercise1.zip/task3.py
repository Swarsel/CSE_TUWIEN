import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import copy    
# Analytical solution
def analyticalResult(x, t):
    n = np.arange(1001)
    return 1 - 2*np.sum((-1)**n / (n+0.5)/np.pi * np.cos((n+0.5)*np.pi*x)*np.exp(-D*((n+0.5)**2)*(np.pi**2)*t))
    
# Parameters    
nx = 31
h = 1
D = 10e-7
#D=1
dt = 800
numTimeSteps = 1000
dx = h/(nx-1)
s = D*dt/dx/dx
print(f"d: {s:.3f}")

# Initial condition
C = np.zeros((numTimeSteps+1, nx,))

# Boundary condition
C[:,0] = 1

for t in range(numTimeSteps):
    a = np.ones((nx-1,))*(-s)
    
    a[-1] = a[-1]*2
    b = np.ones((nx,))*(1+2*s)
    b[0] = 1
    c = np.ones((nx-1,))*(-s)
    c[0] = 0
    d = copy.deepcopy(C[t,:])
    d[0] = 1 
    
    for k in range(1, nx):

        m = a[k-1] / b[k-1]
        b[k] = b[k] - m * c[k-1]
        d[k] = d[k] - m * d[k-1]
        
    C[t+1,-1] = d[-1]/b[-1]
    for k in range(nx-2, -1, -1):
       C[t+1,k] = (d[k] - c[k] * C[t+1,k+1]) / b[k]


xa = np.linspace(0, h, 500)

# Animation
fig, ax = plt.subplots()
x = np.linspace(0, h, nx)
line1, = ax.plot(np.flip(xa), [analyticalResult(xx, 0) for xx in xa], label='Analytical solution', color='b')
line2, = ax.plot(x, C[0,:], color='r', label='Numerical solution', linestyle=(0,(1,10)), linewidth=5)
plt.legend()
ax.set_xlim([0,h])
ax.set_ylim([0,1])
ax.set_title(f"1D unsteady diffusion with Dirichlet/Neumann BC, d={s:.3f}")
ax.set_xlabel("x")
ax.set_ylabel("C")
ax.grid()
def update(frame):

    line2.set_ydata(C[frame,:])
    line1.set_ydata([analyticalResult(xx, frame*dt) for xx in xa])
    return

ani = animation.FuncAnimation(fig=fig, func=update, frames=numTimeSteps, interval=1)
plt.show()
#ani.save("task3_stable.gif")
#writervideo = animation.FFMpegWriter(fps=60)
#ani.save(f'task3_stable.mp4', writer=writervideo)

# Animation
fig, ax = plt.subplots()
x = np.linspace(0, h, nx)
xa = np.linspace(0, h, 500)
line1, = ax.plot(x, [abs(analyticalResult(xx, 0)-C[0,i]) for i,xx in enumerate(np.flip(x))], label='Analytical solution', color='b')

ax.set_xlim([0,h])
#ax.set_ylim([0,1])
ax.set_autoscaley_on
ax.set_title(f"Error of 1D unsteady diffusion with Dirichlet/Neumann BC, d={s:.3f}")
ax.set_xlabel("x")
ax.set_ylabel("Error")
ax.grid()
def update(frame):

    line1.set_ydata([abs(analyticalResult(xx, frame*dt)-C[frame,i]) for i,xx in enumerate(np.flip(x))])
    return

ani = animation.FuncAnimation(fig=fig, func=update, frames=numTimeSteps, interval=1)
plt.show()
#ani.save("task3_error.gif")
#writervideo = animation.FFMpegWriter(fps=60)
#ani.save(f'task3_error.mp4', writer=writervideo)

