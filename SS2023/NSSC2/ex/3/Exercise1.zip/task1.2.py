from matplotlib import pyplot as plt
import numpy as np
from matplotlib.animation import FuncAnimation

D = 1e-6
h = 1.0
Nx = 100
Nt = 2000
dx = h/Nx
dt = 0.5 * dx*dx/D
C = np.zeros(Nx)
C_analy = np.zeros(Nx)
print("dx = ", dx, "dt = ", dt)

# dirichlet boundary conditions
C[0] = 1.0
C[-1] = 0.0
Ct = [np.array(C)]


factor = D * dt/(dx*dx)
for n in range(Nt-1):
    C[1:-1] += factor * (C[0:-2] - 2 * C[1:-1] + C[2:])
    Ct.append(np.array(C))

x = np.linspace(0,h,Nx)
fig = plt.figure()
axis = plt.axes(xlim=(0, h), ylim=(0, 1))

line1, = axis.plot(x, Ct[0], label="numerical solution")
axis.legend()
axis.set_xlabel("x")
axis.set_ylabel("C")


def animate(i):
    line1.set_ydata(Ct[i])


anim = FuncAnimation(fig, animate, frames=Nt)
anim.save('1_2.mp4', writer='ffmpeg', fps=30)
plt.show()
