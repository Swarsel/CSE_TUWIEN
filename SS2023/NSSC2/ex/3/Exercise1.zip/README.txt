Task 1:
task1.1.py can be executed in the terminal with python3 task1.1.py
The simulation properties can be changed within the script.
The corresponding animations are "1_1.mp4" for the stable comparison of analytical and numerical solution and "1_1_unst.mp4" for the unstable case.
The long term result is "1_1long.mp4"

Task 2:
task1.2.py can be executed in the terminal with python3 task1.2.py
The simulation properties can be changed within the script.
The corresponding animations are "1_2.mp4" for the stable numerical solution and "1_2_unst.mp4" for the unstable case.
The long term result is "1_2long.mp4"

Task 3:
The plots in the pdf document are made with task1.3.py, however the error animation was made with task3.py
task3.py can be executed in the terminal with python3 task3.py
The simulation properties can be changed within the script.
The corresponding animations are "task3_stable.mp4" for the comparison of analytical and numerical solution and "task3_error.mp4" for the error

Task 4:
The plots in the pdf document are made with task1.4.py, however the error animation was made with task4.py
task4.py can be executed in the terminal with python3 task4.py
The simulation properties can be changed within the script.
The corresponding animations are "task4_stable.mp4" for the comparison of analytical and numerical solution and "task4_error.mp4" for the error
