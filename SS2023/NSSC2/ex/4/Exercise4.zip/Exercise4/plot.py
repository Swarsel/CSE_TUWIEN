import Plot as p

plotter = p.Plot()
plotter.genPlotsHandIn()


