import numpy as np
import matplotlib.pyplot as plt

# class to generate mesh
class Mesh2D:
    def __init__(self, n, L, hz):
        self._n = n
        self._L = L
        self._hz = hz
        self._coord = None
        self._con = None

    # standard mesh
    def genV0(self):
        L = self._L
        n = self._n
        x = np.linspace(0, L, n)
        self._coord = np.array([[xx,yy] for yy in x for xx in x])
        self._con = np.array([[i+j*n+p, i+1+j*n+p*n, i+n+j*n] for j in range(n-1) for i in range(n-1) for p in range(2)])
        
    # V1    
    def genV1(self):
        L = self._L
        n = self._n
        y = np.linspace(0, L, n)
        self._coord = np.array([[xx, yy] for yy in y for xx in np.linspace(0, L/2+yy/2, n)])
        self._con = np.array([[i+j*n+p, i+1+j*n+p*n, i+n+j*n] for j in range(n-1) for i in range(n-1) for p in range(2)])

    # V2
    def genV2(self):
        L = self._L
        n = self._n
        y = np.linspace(0, L, n)
        self._coord = np.array([[xx*((1-yy/L)/2/L*xx - (L-yy)/2/L + 1), yy] for yy in y for xx in y])
        self._con = np.array([[i+j*n+p, i+1+j*n+p*n, i+n+j*n] for j in range(n-1) for i in range(n-1) for p in range(2)])

    # V3
    def genV3(self):
        L = self._L
        n = self._n
        r = np.linspace(L, 2*L, n)
        phi = np.linspace(np.pi, 5*np.pi/4, n)
        self._coord = np.array([[2*L+rr*np.cos(p), rr*np.sin(p)] for p in phi[::-1] for rr in r])
        self._con = np.array([[i+j*n+p, i+1+j*n+p*n, i+n+j*n] for j in range(n-1) for i in range(n-1) for p in range(2)])

    # plot mesh    
    def plotMesh(self):
        plt.figure()
        for el in self._con:
            plt.plot([self._coord[el[0]][0], self._coord[el[1]][0], self._coord[el[2]][0], self._coord[el[0]][0]], [self._coord[el[0]][1], self._coord[el[1]][1], self._coord[el[2]][1], self._coord[el[0]][1]], color='k')
        plt.show()

    # helper function plot mesh
    def plotMeshHelper(self):
        for el in self._con:
            plt.plot([self._coord[el[0]][0], self._coord[el[1]][0], self._coord[el[2]][0], self._coord[el[0]][0]], [self._coord[el[0]][1], self._coord[el[1]][1], self._coord[el[2]][1], self._coord[el[0]][1]], color='k')
        
