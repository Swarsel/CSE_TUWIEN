import matplotlib.pyplot as plt
import numpy as np
import Mesh2D as me
import HeatCond as s
from print_HTP_2023 import print_HTP

# class to generate plots
class Plot:
    def __init__(self):
        pass

    # generate figure with all required plots
    def genPlot(self, mesh, solver):
        fig = plt.figure(figsize=(16.0, 10.0))

        fig.add_subplot(2,2,1)
        mesh.plotMeshHelper()
        solver.plotTHelper(fig)

        fig.add_subplot(2,2,2)
        solver.plotTgradHelper()

        fig.add_subplot(2,2,3)
        solver.plotFluxesHelper()

        fig.add_subplot(2,2,4)
        solver.plotFluxBoundaryHelper()
        

    # generate plots for handin
    def genPlotsHandIn(self):
        n = 10
        L = 0.01
        hz = 0.001
    
        mesh = me.Mesh2D(n,L,hz)
        meshes = [mesh.genV0, mesh.genV1, mesh.genV2, mesh.genV3]
        for i, m in enumerate(meshes):
            m()
            solver = s.HeatCond(mesh)
            solver.solve(373, 1111.111111113, 236)
            print_HTP(solver._H, solver._T.reshape((n, n)), solver._P.reshape((n, n)), f"V{i}.txt")
            solver.calcGrad()
            solver.calcFluxes()
            self.genPlot(mesh, solver)
            plt.savefig(f"V{i}.png")
            plt.show()

        mesh.genV0()
        domain = [i for i in range(9,15)]+[i for i in range(25,31)]+[i for i in range(41,47)]+[i for i in range(58,63)]+[i for i in range(76,79)]
        solver.solve(373, 1111.111111113, solver.genk(236, 2360, domain))
        solver.calcGrad()
        solver.calcFluxes()
        print_HTP(solver._H, solver._T.reshape((n, n)), solver._P.reshape((n, n)), f"V4a.txt")
        self.genPlot(mesh, solver)
        plt.savefig(f"V4a.png")
        plt.show()
        solver.solve(373, 1111.111111113, solver.genk(236, 23.6, domain))
        solver.calcGrad()
        solver.calcFluxes()
        print_HTP(solver._H, solver._T.reshape((n, n)), solver._P.reshape((n, n)), f"V4b.txt")
        self.genPlot(mesh, solver)
        plt.savefig(f"V4b.png")
        plt.show()

    def debug(self):
        n = 10
        L = 0.01
        hz = 0.001
    
        mesh = me.Mesh2D(n,L,hz)
        mesh.genV0()
        solver = s.HeatCond(mesh)
        solver.solve(373, 1111.111111113, 236)
        print(solver._T)
        print_HTP(solver._H, solver._T.reshape((n, n)), solver._P.reshape((n, n)), f"debug.txt")
        solver.calcGrad()
        solver.calcFluxes()
        self.genPlot(mesh, solver)
        plt.show()