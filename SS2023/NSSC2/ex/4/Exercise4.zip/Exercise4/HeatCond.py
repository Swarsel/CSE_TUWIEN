import numpy as np
import matplotlib.pyplot as plt
import Mesh2D

# class to solve Heat conduction PDE
class HeatCond:
    def __init__(self, mesh):
        self._mesh = mesh
        self._T = None
        self._Tgrad = None
        self._k = None
        self._q = None
        self._qb = 0
        self._P = None
        self._H = None

    # compute element stiffness matrix according to book
    def __computeHe(self, k, p1, p2, p3):
        hz = self._mesh._hz
        b1 = p2[1] - p3[1]
        b2 = p3[1] - p1[1]
        b3 = p1[1] - p2[1]
        c1 = p3[0] - p2[0]
        c2 = p1[0] - p3[0]
        c3 = p2[0] - p1[0]
        delta = (p1[0]*b1 + p2[0]*b2 + p3[0]*b3)/2
        return k*hz/delta/4*np.array([[b1*b1+c1*c1, b1*b2+c1*c2, b1*b3+c1*c3],
            [b2*b1+c2*c1, b2*b2+c2*c2, b2*b3+c2*c3],
            [b3*b1+c3*c1, b3*b2+c3*c2, b3*b3+c3*c3]])
    
    # assemble stiffness matrix and load vector / solve for T
    def solve(self, Td, q, k):
        n = self._mesh._n
        con = self._mesh._con
        coord = self._mesh._coord
        hz = self._mesh._hz
        self._qb = q
        # generate k
        if type(k) is dict:
            pass
        else:
            k = dict.fromkeys([i for i in range(len(con))], k)
        self._k = k

        # assemble H
        H = np.zeros((n*n,n*n))
        P = np.zeros((n*n,))
        for id, el in enumerate(con):
            He = self.__computeHe(k[id], coord[el[0]], coord[el[1]], coord[el[2]])
            for i in range(3):
                for j in range(3):
                    H[el[i], el[j]] += He[i,j] 
        
        self._H = H
        # assemble P for Neumann boundary
        numElements = (n-1)**2
        for i, el in enumerate(con[-1:numElements*2 - (n-1)*2:-2]):
            xb = coord[el[1]][0]
            xa = coord[el[2]][0]
            P[-1-i] -= q*(xb-xa)*hz/2
            P[-2-i] -= q*(xb-xa)*hz/2
           
        # solve for T    
        T = np.zeros((n*n,))
        T[:n] = Td
        T[n:] = np.linalg.solve(H[n:,n:], P[n:] - np.matmul(H[n:,:n], T[:n]))
        self._T = T

        # compute remaining nodal forces
        P[:n] = np.matmul(H[:n,:n], T[:n]) + np.matmul(H[:n, n:], T[n:])
        self._P = P

    # compute Temperature gradient according to exercise sheet
    def calcGrad(self):
        coord = self._mesh._coord
        con = self._mesh._con
        T = self._T
        Tgrad = []
        for el in con:
            p1 = coord[el[0]]
            p2 = coord[el[1]]
            p3 = coord[el[2]]
            b1 = p2[1] - p3[1]
            b2 = p3[1] - p1[1]
            b3 = p1[1] - p2[1]
            c1 = p3[0] - p2[0]
            c2 = p1[0] - p3[0]
            c3 = p2[0] - p1[0]
            delta = (p1[0]*b1 + p2[0]*b2 + p3[0]*b3)/2
            coef = np.array([[b1, b2, b3],[c1, c2, c3]])
            Ti = np.transpose([T[el[0]], T[el[1]], T[el[2]]])
            Tgrad.append(1/2/delta * np.matmul(coef, Ti))
        
        self._Tgrad = np.array(Tgrad)

    # plot Temperature
    def plotT(self):
        fig, ax = plt.figure()
        self.plotTHelper(fig)
        plt.show()

    # helper function to plot Temperature
    def plotTHelper(self, fig):
        n = self._mesh._n
        X = self._mesh._coord[:,0].reshape((n,n))
        Y = self._mesh._coord[:,1].reshape((n,n))
        ax = plt.contourf(X, Y, self._T.reshape((n,n)))
        cb = fig.colorbar(ax, format = '%1.2f')
        cb.ax.set_ylabel('T in K')
        plt.title("Temperature")
        plt.xlabel("x in m")
        plt.ylabel("y in m")

    # helper function to plot temperature gradient
    def plotTgradHelper(self):
        coord = self._mesh._coord
        con = self._mesh._con
        n = self._mesh._n
        
        # compute coordinates
        Xc = []
        Yc = []
        for i, el in enumerate(con):
            if i%2==0:
                x1 = coord[el[0]][0]
                y1 = coord[el[0]][1]
                x2 = coord[el[1]][0]
                y3 = coord[el[2]][1]
                xc = x2/3 + 2*x1/3
                yc = y3/3 + 2*y1/3
                Xc.append(xc)
                Yc.append(yc)
                
            else:
                x2 = coord[el[1]][0]
                x3 = coord[el[2]][0]
                y2 = coord[el[1]][1]
                y1 = coord[el[0]][1]
                xc = x3/3 + 2*x2/3
                yc = y1/3 + 2*y2/3
                Xc.append(xc)
                Yc.append(yc)
            
        numElements = ((n-1)*2)
        
        X = np.array(Xc).reshape((n-1, numElements))
        Y = np.array(Yc).reshape((n-1, numElements))
        Tx = np.array(self._Tgrad[:,0]).reshape((n-1, numElements))
        Ty = np.array(self._Tgrad[:,1]).reshape((n-1, numElements))
            
        self._mesh.plotMeshHelper()
        plt.quiver(X,Y, Tx, Ty)
        plt.title("Temperature gradient")
        plt.xlabel("x in m")
        plt.ylabel("y in m")
        
    # plot temperature gradient
    def plotTgrad(self):
        plt.figure()
        self.plotTgradHelper()
        plt.show()

    # gen k values
    def genk(self, k1, k2, domain):
        n = self._mesh._n
        numElements = ((n-1)*2)*(n-1)
        return {id: (k1 if id not in domain else k2) for id in range(numElements)}

    # compute fluces
    def calcFluxes(self):
        Tgrad = self._Tgrad
        k = self._k
        q = np.zeros(Tgrad.shape)
       
        for id, Tg in enumerate(Tgrad):
            q[id] = - k[id] * Tg
            
        self._q = q

    # helper function to plot fluxes
    def plotFluxesHelper(self):
        q = self._q
        coord = self._mesh._coord
        con = self._mesh._con
        n = self._mesh._n
        Xc = []
        Yc = []
        
        for i, el in enumerate(con):
            if i%2==0:
                x1 = coord[el[0]][0]
                y1 = coord[el[0]][1]
                x2 = coord[el[1]][0]
                y3 = coord[el[2]][1]
                xc = x2/3 + 2*x1/3
                yc = y3/3 + 2*y1/3
                Xc.append(xc)
                Yc.append(yc)
                
            else:
                x2 = coord[el[1]][0]
                x3 = coord[el[2]][0]
                y2 = coord[el[1]][1]
                y1 = coord[el[0]][1]
                xc = x3/3 + 2*x2/3
                yc = y1/3 + 2*y2/3
                Xc.append(xc)
                Yc.append(yc)
            
        numElements = ((n-1)*2)
        
        X = np.array(Xc).reshape((n-1, numElements))
        Y = np.array(Yc).reshape((n-1, numElements))
        qx = np.array(q[:,0]).reshape((n-1, numElements))
        qy = np.array(q[:,1]).reshape((n-1, numElements))
            
        self._mesh.plotMeshHelper()
        plt.quiver(X,Y, qx, qy)
        plt.title("Fluxes")
        plt.xlabel("x in m")
        plt.ylabel("y in m")

    # plot fluxes
    def plotFluxes(self):
        plt.figure()
        self.plotFluxesHelper()
        plt.show()

    # helper function plot boundary fluxes
    def plotFluxBoundaryHelper(self):
        n = self._mesh._n
        q = self._q
        x1 = self._mesh._coord[-self._mesh._n:,0]

        x2 = np.zeros((n*2-2,))
        x2[:-1:2] = 2*x1[:-1]/3 + x1[1:]/3
        x2[1::2] = x1[:-1]/3 + 2*x1[1:]/3
        
        plt.plot(x1, self._qb*np.ones((len(x1),)), label='boundary fluxes')
        plt.plot(x2, q[-(n-1)*2::1,0], label=r'numerical $q_x$')
        plt.plot(x2, q[-(n-1)*2::1,1], label=r'numerical $q_y$')
        plt.legend()
        plt.title("Fluxes at Neumann boundary")
        plt.xlabel("x")
        plt.grid()
        plt.ylabel(r"q in $W/m^2$")
        
