HeatCond.py: class which generates H,P and solves for T. Generates various plots.
Mesh2D.py: class which generates different meshes
Plot.py: class which generates required plots and outputs. To generate valid plots the solve(), calcGrad(), and calcFluxes() methods of an HeatCond object have to be called before the genPlot() method of the Plot object.

plot.py: execution by running python3 plot.py in terminal. Calls the required methods to generate required output

Used modules: numpy and matplotlib
