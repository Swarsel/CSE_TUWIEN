#!/usr/bin/env python
import sys
import numpy
import jax
import jax.numpy as np
import os
import time


ts = time.time()


def Morse(positions, L=15.0):
    """potential in reduced units."""
    De = 1.6
    alpha = 3.028
    re = 1.411
    # Compute all relative positions between pairs without iterating.
    delta = positions[:, np.newaxis, :] - positions
    # Take only the combinations of two different atoms.
    indices = np.triu_indices(positions.shape[0], k=1)
    delta = delta[indices[0], indices[1], :]
    # Compute the minimum image
    delta = np.abs(delta)
    delta -= np.floor(delta / L + 0.5) * L
    # Compute the squared distances and evaluate the potential energy.
    r = np.linalg.norm(delta, axis=1)
    # Compute V(r)
    exp = np.exp(-alpha * (r - re))
    return De * ((1.0 - exp) ** 2.0 - 1.0).sum()


# get arguments
print("Number of arguments:", len(sys.argv), "arguments.")
print("Argument List:", str(sys.argv))
filename = "output_alt.txt"
dt = 0.04
N = 1000
if len(sys.argv) == 4:
    filename, dt, N = str(sys.argv[1]), float(sys.argv[2]), float(sys.argv[3])
print("file : ", filename, "dt: ", dt, "N: ", N)

# read snapshot
with open(filename, "r") as file:
    lines = [line.split() for line in file]
M = int(lines[0][0])
x = np.empty((M, 3))
v = np.empty((M, 3))
L = float(lines[2][0])
src = np.float_(lines[3:])
x = src[:, :3]
v = src[:, 3:]

m = 18.998403
funs = jax.jit(jax.value_and_grad(Morse))  # Automatic gradient function

# calculate newton's equations of motion
# write trajectory to file
filename = "trajectory.txt"
if os.path.exists(filename):
    os.remove(filename)
with open(filename, "a") as file:
    E, a = funs(x, L)
    arr = np.concatenate((x, v), axis=1)
    file.write("{}\n{}\n{}\n".format(M, E, L))
    numpy.savetxt(file, arr, fmt="%.4g")
    for i in range(1, N):
        x += dt * (v + 0.5 * a * dt)
        E, a_t = funs(x, L)
        a_t = np.reshape(-a_t / m, (-1, 3))
        v += 0.5 * (a + a_t) * dt
        a = a_t
        arr = np.concatenate((x, v), axis=1)
        file.write("{}\n{}\n{}\n".format(M, E, L))
        numpy.savetxt(file, arr)
        print("done with iteration ", i)

print("runtime in seconds: ", time.time() - ts)
