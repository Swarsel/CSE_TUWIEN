#!/usr/bin/env python
import sys
import numpy as np
import scipy.constants
import networkx as nx
import matplotlib.pyplot as plt

# get arguments
print("Number of arguments:", len(sys.argv), "arguments.")
print("Argument List:", str(sys.argv))
filename = "trajectory.txt"
distngb = 1.411
if len(sys.argv) == 3:
    filename, distngb = str(sys.argv[1]), float(sys.argv[2])
print("file : ", filename, "distance: ", distngb)

# Read snapshots of trajectory
with open(filename, "r") as file:
    lines = [line.split() for line in file]
M = int(lines[0][0])
N = len(lines) // (M + 3)
L = float(lines[2][0])
x = []
v = []
for i in range(len(lines) // (M + 3)):
    src = np.float_(lines[i * (M + 3) + 3 : (i + 1) * (M + 3)])
    x.append(src[:, :3])
    v.append(src[:, 3:])
atomsX = np.array(x)
atomsV = np.array(v)

# Compute kinetic energy at each time step
Ekin = np.zeros((N, 1))
m = 18.998403
kB = 8.617333262 * 1e-5
for i, t in enumerate(atomsV):
    Ekin[i] = np.sum(np.sum(np.power(t, 2), axis=1)) * m / 2
T = Ekin / (1.5 * M * kB)

dt = 0.04
timesteps = np.linspace(0, N * dt, N)
plt.plot(timesteps, T)
plt.title("Temperature of the system over time")
plt.xlabel("time in $s_a$")
plt.ylabel("Temperature in K")
plt.show()

# Estimate specific heat
# second half of trajectory
sh = int(np.floor(N / 2))
l = Ekin.shape[0] - sh

# average kinetic energy
EkinAve = np.sum(Ekin[sh:]) / l

# sigma squared
sigEkin = np.sum(np.power(Ekin[sh:] - EkinAve, 2)) / l
cv = scipy.constants.k * EkinAve * EkinAve / sigEkin

# Pair distribution function Version 1
# bin dictionary
nBins = 500
bin = dict.fromkeys(np.arange(nBins), 0)
dr = L / 2 / nBins
# homogeneous density
rho = M / (L**3)
# array with volumes
vol = [
    4.0 / 3.0 * scipy.pi * (((n + 1) * dr) ** 3 - (n * dr) ** 3) for n in range(nBins)
]
for positions in atomsX:
    # delta like in lecture
    delta = positions[:, np.newaxis, :] - positions
    indices = np.triu_indices(positions.shape[0], k=1)
    delta = delta[indices[0], indices[1], :]
    delta = delta - L * ((delta / L).round())
    r2 = np.sqrt((delta * delta).sum(axis=1))
    # only use values in nearest image convention
    r2 = r2[r2 < L / 2]
    # get indices for bins
    k = np.floor(r2 / dr)

    # count bins
    for kk in k:
        bin[kk] += 2

# take average and normalize bins
bin.update((k, b / (rho * vol[k]) / N / M) for k, b in bin.items())
plt.figure()
x = np.linspace(0, L / 2 - dr, nBins)
plt.bar(x, bin.values(), width=dr, align="edge")
plt.title("Pair distribution function")
plt.xlabel("distance between pairs in $\AA$")
plt.ylabel("number of pairs")
plt.show()


# Adjecancy matrix
connMatrix = np.zeros((M, M))
visAtoms = []
bin = dict.fromkeys(np.arange(1, M + 1), 0)

# Loop over all timesteps
for atoms in atomsX:
    # Loop over all atoms
    for i, oneAtom in enumerate(atoms):
        # Difference
        diff = atoms - oneAtom
        # Nearest image convention
        diff = diff - L * ((diff / L).round())
        # Distances smaller than given cutoff distance to still be considered neighbour
        dist = np.linalg.norm(diff, axis=1) <= distngb
        connMatrix[i] = dist

    # Generate networkx graph from adjecancy matrix
    G = nx.from_numpy_array(connMatrix)

    # Compute connected components and count them
    for c in nx.connected_components(G):
        bin[len(c)] += 1

# Compute average over timesteps
bin.update((k, b / N) for k, b in bin.items())

plt.figure()
x = np.linspace(1, M, M)
plt.bar(x, bin.values(), width=1, align="edge")
plt.title("Connected Components")
plt.xlabel("Size of connected components in number of atoms")
plt.ylabel("Number of components")
plt.show()
