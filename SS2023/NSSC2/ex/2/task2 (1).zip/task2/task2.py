#!/usr/bin/env python
import sys
import numpy
import numpy.random as random
import jax
import jax.numpy as np
import scipy as sp


def Morse(positions, L=15.0):
    """potential in reduced units."""
    De = 1.6
    alpha = 3.028
    re = 1.411
    positions = np.reshape(positions, (-1, 3))
    # Compute all relative positions between pairs without iterating.
    delta = positions[:, np.newaxis, :] - positions
    # Take only the combinations of two different atoms.
    indices = np.triu_indices(positions.shape[0], k=1)
    delta = delta[indices[0], indices[1], :]
    # Compute the minimum image
    delta = np.abs(delta)
    delta -= np.floor(delta / L + 0.5) * L
    # Compute the distances and evaluate the potential energy.
    r = np.linalg.norm(delta, axis=1)
    # Compute V(r)
    exp = np.exp(-alpha * (r - re))
    return De * ((1.0 - exp) ** 2.0 - 1.0).sum()


# get arguments
print("Number of arguments:", len(sys.argv), "arguments.")
print("Argument List:", str(sys.argv))
M = 1000
L = 15.0
T = 300.0
if len(sys.argv) == 4:
    M, L, T = int(sys.argv[1]), float(sys.argv[2]), float(sys.argv[3])
print("M : ", M, "L: ", L, "T: ", T)

E_pot = jax.jit(Morse)
E_pot_gradient = jax.jit(jax.grad(Morse))  # Automatic gradient function
# Put M particles in a cube of side L
test_positions = L * random.random_sample(3 * M)
e_pot_before = E_pot(test_positions, L)
# Move particles to local energy minimum using CG
min_E_positions = sp.optimize.minimize(
    E_pot, test_positions, args=(L), method="CG", jac=E_pot_gradient
).x
e_pot = E_pot(min_E_positions, L)
forces = -E_pot_gradient(min_E_positions)
forces = np.reshape(forces, (-1, 3))
sum_forces = forces.sum(axis=0)
# assign random velocities
m = 18.998403
kB = 8.617333262 * 1e-5
sigma = np.sqrt(kB * T / m)  # mean and standard deviation
v = random.default_rng().normal(0.0, sigma, (M, 3))
v -= v.mean(axis=0)

print(
    "Potential energy before:",
    e_pot_before,
    "Potential energy:",
    e_pot,
    "Forces:",
    forces,
    "sum of Forces:",
    sum_forces,
    "velocity: ",
    v,
    sep="\n",
)
# write values to file
with open("output_alt.txt", "w") as file:
    file.write("{}\n".format(M))
    file.write("\n")
    file.write("{}\n".format(L))
    positions = np.reshape(min_E_positions, (-1, 3))
    arr = np.concatenate((positions, v), axis=1)
    numpy.savetxt(file, arr)
