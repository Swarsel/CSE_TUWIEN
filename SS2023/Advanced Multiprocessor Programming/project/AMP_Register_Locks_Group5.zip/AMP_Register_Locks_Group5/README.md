# AMP_Filter
Project 1: Register Locks

Florian Fritzer, Markus Hickel, Leon Schwarzaeugl

```make benchmark```

builds main benchmark binary (bin/benchmark)

```
Usage: ./benchmark <lockname> <benchmarktype> <num_iterations> <num_threads> <duration> <outdir>
Possible values for lockname: filter, openmp, blockwoo, tree, alagarsamy
Possible values for benchmarktype: throughput, throughputsleep, fairness, overtake, latency
```

``` make small-bench```

runs the required max 1 minute small benchmark.

``` make small-plot```

creates a virtual python environment and installs matplotlib + pandas to create the plots.

throughput, throughputsleep, fairness and latency are time based benchmark. The num_iteration input arg will not be used,
instead the benchmark will run for duration amount of seconds.

The overtake benchmark uses a fixed number of iterations for every thread (num_iterations).

The overtake benchmark also includes the correctness test. If the file $LOCKNAME_correct_correctness.txt is empty,
the lock worked fine.

All the plots for the different benchmarks are located in "plots_nebula/" and "plots_vsc/".

The slurm scripts can be used to run the specific benchmarks for the different locks.
