#!/bin/bash

folder=res_vsc



python plot_scripts/multiple_locks_throughput_new.py ${folder}/alagarsamy_throughput.txt $folder/blockwoo_throughput.txt ${folder}/filter_throughput.txt ${folder}/openmp_throughput.txt ${folder}/tree_throughput.txt plots_vsc

    python plot_scripts/locks_throughput.py ${folder}/alagarsamy_throughput.txt plots_vsc
    python plot_scripts/locks_throughput.py ${folder}/blockwoo_throughput.txt plots_vsc
    python plot_scripts/locks_throughput.py ${folder}/filter_throughput.txt plots_vsc
    python plot_scripts/locks_throughput.py ${folder}/openmp_throughput.txt plots_vsc
    python plot_scripts/locks_throughput.py ${folder}/tree_throughput.txt plots_vsc


threads=(2 4 8 16 32 64)

for i in "${threads[@]}"
do
	python plot_scripts/locks_acquired.py ${folder}/alagarsamy_acquisitions.txt $i plots_vsc
	python plot_scripts/locks_acquired.py ${folder}/blockwoo_acquisitions.txt $i plots_vsc
	python plot_scripts/locks_acquired.py ${folder}/filter_acquisitions.txt $i plots_vsc
	python plot_scripts/locks_acquired.py ${folder}/openmp_acquisitions.txt $i plots_vsc
	python plot_scripts/locks_acquired.py ${folder}/tree_acquisitions.txt $i plots_vsc

	python plot_scripts/locks_overtakes.py ${folder}/alagarsamy_overtakes.txt $i plots_vsc
	python plot_scripts/locks_overtakes.py ${folder}/blockwoo_overtakes.txt $i plots_vsc
    python plot_scripts/locks_overtakes.py ${folder}/filter_overtakes.txt $i plots_vsc
    python plot_scripts/locks_overtakes.py ${folder}/openmp_overtakes.txt $i plots_vsc
    python plot_scripts/locks_overtakes.py ${folder}/tree_overtakes.txt $i plots_vsc

    python plot_scripts/locks_latencies.py ${folder}/alagarsamy_latency.txt $i plots_vsc
    python plot_scripts/locks_latencies.py ${folder}/blockwoo_latency.txt $i plots_vsc
    python plot_scripts/locks_latencies.py ${folder}/filter_latency.txt $i plots_vsc
    python plot_scripts/locks_latencies.py ${folder}/openmp_latency.txt $i plots_vsc
    python plot_scripts/locks_latencies.py ${folder}/tree_latency.txt $i plots_vsc
	


done



