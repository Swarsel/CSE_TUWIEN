#ifndef TREE_HPP
#define TREE_HPP

#include <atomic>
#include <vector>
#include <PetersonLock2.hpp>
#include "LockBase.hpp"

class Tree : public LockBase{
private:
	int threads;
	int n;
	std::vector<PetersonLock2*> locks;
	void unlock(int index);
	void createLocks(int index, int lessThan, int size);
	int getLeafLock();
	static int getLeftChild(int index) {
        return 2*index;
    }
	static int getRightChild(int index) {
        return 2*index+1;
    }
	int nearestPowerOf2(int threads);

public:
	Tree(int threads);
	~Tree();
	void lock() override;
        void lockOvertake() override;
	void unlock() override;
};

#endif  // TREE_HPP
