#ifndef LOCK_HPP
#define LOCK_HPP
#include <omp.h>
#include "LockBase.hpp"

class OpenmpLock : public LockBase {
public:
	OpenmpLock(int num_threads);
	~OpenmpLock();
	void lock();
	void lockOvertake();
	void unlock();

private:
	omp_lock_t omplock;
  int n;
};
#endif
