#ifndef DATA_GATHER_HPP
#define DATA_GATHER_HPP

#include <map>
#include <vector>
#include <string>

class DataGather {
public:
	DataGather() = default;
    DataGather(const std::string& lock_name);
    void addBenchmarkResult(int num_threads, const std::vector<double>& throughput_values, const std::vector<std::vector<int>>& lock_acquisitions,
                            const std::vector<int>& overtakes, int counter, int total_iterations,const std::vector<double>& averaged_latency_values);
	void saveResults(const std::string& throughput_file, const std::string& lock_acquisitions_file, const std::string& overtakes_file, const std::string& overtakes_count_file,const std::string& latency_file);
	void setLocktype(std::string locktype) {lock_name = locktype;};
	void setOutdir(const std::string& dir) { outdir = dir; }
private:
    std::string lock_name;
	std::string outdir;
    std::map<int, std::vector<std::vector<double>>> throughput_data;
    std::map<int, std::vector<std::vector<std::vector<int>>>> lock_acquisitions_data;
    std::map<int, std::vector<std::vector<int>>> overtakes_data;
    std::map<int, std::vector<int>> overtakes_count_data;
    std::map<int, int> total_iterations_data;
	std::map<int, int> counter_data;
	std::map<int, std::vector<std::vector<double>>> averaged_latency_data;

    void saveThroughputData(const std::string& filename);
    void saveLockAcquisitionsData(const std::string& filename);
	void saveOvertakesData(const std::string& filename);
	void saveOvertakesCountData(const std::string& filename);
	void saveAveragedLatencyData(const std::string& filename);

};

#endif  // DATA_GATHER_HPP

