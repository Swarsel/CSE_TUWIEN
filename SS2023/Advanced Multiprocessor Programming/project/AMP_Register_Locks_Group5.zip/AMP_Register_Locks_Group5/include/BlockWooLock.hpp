#ifndef BLOCKWOOLOCK_HPP
#define BLOCKWOOLOCK_HPP

#include "LockBase.hpp"
#include <atomic>

class BlockWooLock : public LockBase {
public:
	BlockWooLock(int num_threads);
	~BlockWooLock();
	void lock() override;
        void lockOvertake() override;
	void unlock() override;
private:
        std::atomic<int>* Q;
        std::atomic<int>* turn;
	int n;
};
#endif 
