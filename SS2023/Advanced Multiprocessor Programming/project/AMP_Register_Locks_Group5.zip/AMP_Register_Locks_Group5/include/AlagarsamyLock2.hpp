#ifndef ALAGARSAMYLOCK2_HPP
#define ALAGARSAMYLOCK2_HPP

#include "LockBase.hpp"
#include <atomic>

class AlagarsamyLock2 : public LockBase {
public:
	AlagarsamyLock2(int num_threads);
	~AlagarsamyLock2();
	void lock() override;
        void lockOvertake() override;
	void unlock() override;
private:
	std::atomic<int>* Q;
	std::atomic<int>* turn;
	int n;
};
#endif 
