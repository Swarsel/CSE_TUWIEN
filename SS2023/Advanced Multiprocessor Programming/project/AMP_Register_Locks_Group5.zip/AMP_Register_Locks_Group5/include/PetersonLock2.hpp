#ifndef PETERSONLOCK2_HPP
#define PETERSONLOCK2_HPP

#include <atomic>

class PetersonLock2 {
private:
	std::atomic<int> victim;
	std::atomic<int> index;
	std::atomic<bool> flag[2];

public:
	PetersonLock2(int index);
	~PetersonLock2();
	void lock();
	void unlock();
};

#endif  // PETERSONLOCK2_HPP