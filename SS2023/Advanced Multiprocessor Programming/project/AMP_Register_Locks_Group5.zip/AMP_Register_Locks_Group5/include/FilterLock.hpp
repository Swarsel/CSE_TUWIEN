#ifndef FILTERLOCK_HPP
#define FILTERLOCK_HPP

#include "LockBase.hpp"
#include <atomic>

class FilterLock : public LockBase {
public:
	FilterLock(int num_threads);
	~FilterLock();
	void lock() override;
	void lockOvertake() override;
	void unlock() override;
private:
	//int* level;
	//int* victim;
	std::atomic<int>* level;
	std::atomic<int>* victim;
	int n;
};
#endif 
