#ifndef LOCKBASE_HPP
#define LOCKBASE_HPP

#include <vector>

class LockBase {
public:
	virtual ~LockBase() {}
	virtual void lock() = 0;
        virtual void lockOvertake() = 0;
	virtual void unlock() = 0;
	std::vector<int> T;

};

#endif
