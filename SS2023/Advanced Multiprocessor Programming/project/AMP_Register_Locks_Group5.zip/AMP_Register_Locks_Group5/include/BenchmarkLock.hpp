#ifndef BENCHMARKS
#define BENCHMARKS

#include <string>
#include <vector>
#include "DataGather.hpp"
class LockBase;

//void Throughput_iter(LockBase *Lock, int num_threads, int num_iter, const std::string& output_file);
void Throughput_time(LockBase *Lock, int num_threads, double duration, const std::string& lock_name, DataGather& data_gather);
void Throughput_iter(LockBase *Lock, int num_threads, int num_iter, const std::string& lock_name, DataGather& data_gather);
void ThroughputSleep_iter(LockBase *Lock, int num_threads, int num_iter, const std::string& lock_name, DataGather& data_gather);
void Latency_iter(LockBase *Lock, int num_threads, int num_iter, const std::string& lock_name, DataGather& data_gather);
void Fairness_iter(LockBase *Lock, int num_threads, int num_iter, const std::string& lock_name, DataGather& data_gather);
void OvertakeCorrectness_iter(LockBase *Lock, int num_threads, int num_iter, const std::string& lock_name, DataGather& data_gather);
void Fairness_time(LockBase *Lock, int num_threads, double duration, const std::string& lock_name, DataGather& data_gather);
void ThroughputSleep_time(LockBase *Lock, int num_threads, int duration, const std::string& lock_name, DataGather& data_gather);
void Latency_time(LockBase *Lock, int num_threads, int duration, const std::string& lock_name, DataGather& data_gather);
#endif // BENCHMARKS

