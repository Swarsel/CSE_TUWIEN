#!/bin/bash

threads=(2 4 8 16 32 64)
duration=1

for i in "${threads[@]}"
do
for a in {1..30}
do

benchmark alagarsamy throughput 100000 $i $duration res
benchmark alagarsamy fairness  100000 $i $duration res
benchmark alagarsamy overtake 3000 $i $duration res
benchmark alagarsamy latency  100000 $i $duration res

done
done
