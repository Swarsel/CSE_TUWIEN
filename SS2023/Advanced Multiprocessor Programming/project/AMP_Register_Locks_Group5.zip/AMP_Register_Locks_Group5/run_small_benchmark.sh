#!/bin/bash

prefix=bin

$prefix/benchmark tree fairness  1 5 3 res_small_bench
$prefix/benchmark tree fairness  1 8 3 res_small_bench

$prefix/benchmark alagarsamy fairness  1 5 3 res_small_bench
$prefix/benchmark alagarsamy fairness  1 8 3 res_small_bench

$prefix/benchmark filter throughput 1 2 2 res_small_bench
$prefix/benchmark alagarsamy throughput 1 2 2 res_small_bench
$prefix/benchmark blockwoo throughput 1 2 2 res_small_bench
$prefix/benchmark openmp throughput 1 2 2 res_small_bench
$prefix/benchmark tree throughput 1 2 2 res_small_bench

$prefix/benchmark filter throughput 1 8 2 res_small_bench
$prefix/benchmark alagarsamy throughput 1 8 2 res_small_bench
$prefix/benchmark blockwoo throughput 1 8 2 res_small_bench
$prefix/benchmark openmp throughput 1 8 2 res_small_bench
$prefix/benchmark tree throughput 1 8 2 res_small_bench

$prefix/benchmark filter throughput 1 32 2 res_small_bench
$prefix/benchmark alagarsamy throughput 1 32 2 res_small_bench
$prefix/benchmark blockwoo throughput 1 32 2 res_small_bench
$prefix/benchmark openmp throughput 1 32 2 res_small_bench
$prefix/benchmark tree throughput 1 32 2 res_small_bench

$prefix/benchmark filter overtake 3000 8 1 res_small_bench
$prefix/benchmark blockwoo overtake 3000 8 1 res_small_bench
$prefix/benchmark alagarsamy overtake 3000 8 1 res_small_bench

$prefix/benchmark filter throughputsleep 100000 64 2 res_small_bench
$prefix/benchmark alagarsamy throughputsleep 100000 64 2 res_small_bench
$prefix/benchmark blockwoo throughputsleep 100000 64 2 res_small_bench

$prefix/benchmark alagarsamy latency  1 32 2 res_small_bench
$prefix/benchmark openmp latency  1 32 2 res_small_bench


