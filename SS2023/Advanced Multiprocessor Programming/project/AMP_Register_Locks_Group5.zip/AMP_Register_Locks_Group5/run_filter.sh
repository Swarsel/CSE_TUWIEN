#!/bin/bash

threads=(2 4 8 16 32 64)
duration=1

for i in "${threads[@]}"
do
for a in {1..30}
do

benchmark filter throughput 100000  $i $duration res
benchmark filter fairness  100000  $i $duration res
benchmark filter overtake 3000  $i $duration res
benchmark filter latency 3000  $i $duration res

done
done
