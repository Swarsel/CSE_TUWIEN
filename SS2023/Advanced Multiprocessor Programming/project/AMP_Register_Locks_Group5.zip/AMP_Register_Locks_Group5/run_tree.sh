#!/bin/bash

threads=(2 4 8 16 32 64)
duration=1

for i in "${threads[@]}"
do
for a in {1..30}
do

benchmark tree throughput 100000 $i $duration res
benchmark tree fairness  100000 $i $duration res
benchmark tree overtake 10000  $i $duration res
benchmark tree latency 10000  $i $duration res

done
done
