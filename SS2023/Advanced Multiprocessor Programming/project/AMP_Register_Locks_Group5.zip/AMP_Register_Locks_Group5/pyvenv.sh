#!/bin/bash 
 
VENV_DIR="pyvenv" 
python3 -m venv "$VENV_DIR" 
source "$VENV_DIR/bin/activate" 
pip install --upgrade pip 
pip install matplotlib pandas
source ./pyvenv/bin/activate
