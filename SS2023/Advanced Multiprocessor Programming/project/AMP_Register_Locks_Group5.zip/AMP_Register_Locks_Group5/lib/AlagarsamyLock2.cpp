#include <iostream>
#include <vector>
#include <algorithm>
#include <atomic>
#include <numeric>
#include <omp.h>
#include <chrono>
#include <thread>
#include "AlagarsamyLock2.hpp"

using namespace std;

// Q = level
// turn = victim


AlagarsamyLock2::AlagarsamyLock2(int num_threads) {
	n = num_threads;
    Q = new atomic<int>[n];
    turn = new atomic<int>[n+1];
	for (int i = 0; i < n; i++) {
		Q[i]=0;
	}
    for (int i = 0; i < n+1; i++) {
		turn[i]=-1;
	}
}

AlagarsamyLock2::~AlagarsamyLock2() {
	delete[] Q;
	delete[] turn;
}

void AlagarsamyLock2::lockOvertake() {
	int i = omp_get_thread_num();
	int j = 0;
	do {
		j++;
        if (j==1) {
            #pragma omp critical
            {
                T.push_back(omp_get_thread_num());
                Q[i].store(j);
            }
        }
        else Q[i].store(j);
		turn[j].store(i);
        bool cond2 = true;
        while ((turn[j].load() == i) && cond2) {
            cond2 = false;
            int sum = 0;
            for (int k=0; k < n; k++) {
                if (k!=i) {
                    if (Q[k].load() >= j) {
                        cond2 = true;
                    }
                }
                if (Q[k].load() != 0) {
                    sum ++;
                }
            }
            if (sum > j) {
                cond2 = true;
            }
        }
		
	} while (turn[j].load() != i);
	#pragma omp critical
    {
        T.push_back(omp_get_thread_num()+n);
    }
}

void AlagarsamyLock2::lock() {
	int i = omp_get_thread_num();
	int j = 0;
	do {
		j++;
        Q[i].store(j);
		turn[j].store(i);
        bool cond2 = true;
        while ((turn[j].load() == i) && cond2) {
            cond2 = false;
            int sum = 0;
            for (int k=0; k < n; k++) {
                if (k!=i) {
                    if (Q[k].load() >= j) {
                        cond2 = true;
                    }
                }
                if (Q[k].load() != 0) {
                    sum ++;
                }
            }
            if (sum > j) {
                cond2 = true;
            }
        }
		
	} while (turn[j].load() != i);
}
 
void AlagarsamyLock2::unlock() {
    int i = omp_get_thread_num();
    int j = Q[i].load();
    int lowest = n;
    for (int p=0;p<n;p++) {
        if ((Q[p].load()>0) && (Q[p].load()<lowest)) {
            lowest=p;
        }
    }
    turn[lowest].store(i);
    for (int k=1; k<j;k++) {
        for (int p=0; p<n;p++) {
            if (p!=i) {
                while ((Q[p].load()>0) && (turn[Q[p].load()].load()!=p)) {}
            }
        }
    }
    // turn[0].store(i);
    // for (int p=0; p<n;p++) {
    //     if (p!=i) {
    //         while ((Q[p].load()>0) && (turn[Q[p].load()].load()!=p)) {}
    //     }
    // }
    Q[i].store(0);
}
