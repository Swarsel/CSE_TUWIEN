#include <iostream>
#include <vector>
#include <algorithm>
#include <atomic>
#include <numeric>
#include <omp.h>
#include "BlockWooLock.hpp"

using namespace std;

// Q = level
// turn = victim


BlockWooLock::BlockWooLock(int num_threads) {
	n = num_threads;
	Q = new atomic<int>[n];
	turn = new atomic<int>[n];
	for (int i = 0; i < n; i++) {
		Q[i]=0;
	}
}

BlockWooLock::~BlockWooLock() {
	delete[] Q;
	delete[] turn;
}

void BlockWooLock::lock() {
	int me = omp_get_thread_num();
	int i = 0;
    Q[me].store(1);
	do {
		i++;
		turn[i].store(me);
		while (accumulate(Q, Q+n, 0) > i && turn[i].load() == me) {}
	} while (turn[i].load() != me);
	
}

void BlockWooLock::lockOvertake() {
	int me = omp_get_thread_num();
	int i = 0;
	#pragma omp critical
	{
		T.push_back(omp_get_thread_num());
		Q[me].store(1);
	}
	do {
		i++;
		turn[i].store(me);
		while (accumulate(Q, Q+n, 0) > i && turn[i].load() == me) {}
	} while (turn[i].load() != me);
	#pragma omp critical
	{
			T.push_back(omp_get_thread_num()+n);
	}
}

void BlockWooLock::unlock() {
	int me = omp_get_thread_num();
	Q[me].store(0);
}
