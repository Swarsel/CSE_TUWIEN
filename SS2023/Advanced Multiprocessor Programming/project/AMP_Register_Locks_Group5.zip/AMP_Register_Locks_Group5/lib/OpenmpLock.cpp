#include <OpenmpLock.hpp>


OpenmpLock::OpenmpLock(int num_threads) : n(num_threads) {
	omp_init_lock(&omplock);
}

OpenmpLock::~OpenmpLock() {
        omp_destroy_lock(&omplock);
}

void OpenmpLock::lock() {
	
	omp_set_lock(&omplock);
	
}

void OpenmpLock::lockOvertake() {
	#pragma omp critical
    {
        T.push_back(omp_get_thread_num());
    }
	omp_set_lock(&omplock);
	#pragma omp critical
    {
        T.push_back(omp_get_thread_num()+n);
    }
}



void OpenmpLock::unlock() {
	omp_unset_lock(&omplock);
}
