#include "Tree.hpp"
#include <omp.h>
#include <thread>
#include <iostream>
#include <PetersonLock2.hpp>
#include <math.h>



Tree::Tree(int n) : n(n), threads(nearestPowerOf2(n)), locks(threads) {
	// instantiate and configure each Peterson lock
	createLocks(1, threads/2, threads/2);
}
Tree::~Tree() {
	for (int i=0;i<locks.size();i++) {
		delete locks[i];
	}
}


void Tree::lock()
{
	// start at the leaf node lock for current thread
	int index = getLeafLock();

	// root is index 1, so exit the while loop when index 0 (index of
	// unitialized node lock) is reached.
	while (index != 0)
	{
		(*locks[index]).lock();
		index /= 2;
	}
}
void Tree::lockOvertake()
{
	// start at the leaf node lock for current thread
	int index = getLeafLock();

	// root is index 1, so exit the while loop when index 0 (index of
	// unitialized node lock) is reached.
	while (index != 0)
	{
		if (index==getLeafLock()) {
            #pragma omp critical
            {
                T.push_back(omp_get_thread_num());
            }
        }
		(*locks[index]).lock();
		index /= 2;
	}
	#pragma omp critical
	{
		T.push_back(omp_get_thread_num()+n);
	}
}


void Tree::unlock()
{
	unlock(getLeafLock()); // call unlock(int) on leaf node for thread
}

void Tree::unlock(int index)
{
	if (index != 0)
	{
		unlock(index/2);
		(*locks[index]).unlock(); // post-order: unlock after recursive call
								// to unlock from root down to leaf
	}
}


void Tree::createLocks(int index, int lessThan, int size)
{
	if (index < threads)
	{
		// instantiate Peterson lock at specified node
		locks[index] = new PetersonLock2(lessThan);

		// instantiate the left and right subtrees of this node
		size /= 2;
		createLocks(getLeftChild(index), lessThan - size, size);
		createLocks(getRightChild(index), lessThan + size, size);
	}
}

int Tree::getLeafLock()
{
	return (threads + omp_get_thread_num())/2;
}

int Tree::nearestPowerOf2(int N)
{
    int a = log2(N);
 
    if (pow(2, a) == N)
        return N;
 
    return pow(2, a + 1);
}
