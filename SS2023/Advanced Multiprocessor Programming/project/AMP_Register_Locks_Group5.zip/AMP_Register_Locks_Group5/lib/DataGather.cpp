#include "DataGather.hpp"
#include <fstream>
#include <iostream>
#include <iomanip>
#include <numeric>

DataGather::DataGather(const std::string& lock_name) : lock_name(lock_name) {}

void DataGather::addBenchmarkResult(int num_threads, const std::vector<double>& throughput_values, const std::vector<std::vector<int>>& lock_acquisitions, const std::vector<int>& overtakes, int counter, int total_iterations, const std::vector<double>& averaged_latency_values) {
    throughput_data[num_threads].push_back(throughput_values);
    lock_acquisitions_data[num_threads].push_back(lock_acquisitions);
	overtakes_data[num_threads].push_back(overtakes);
    overtakes_count_data[num_threads].push_back(counter);
    total_iterations_data[num_threads] = total_iterations;
	counter_data[num_threads] = counter;
	averaged_latency_data[num_threads].push_back(averaged_latency_values);
}

void DataGather::saveResults(const std::string& throughput_file = "", const std::string& lock_acquisitions_file = "", const std::string& overtakes_file = "", const std::string& overtakes_count_file = "", const std::string& latency_file = "") {
    if (!throughput_file.empty()) {
        saveThroughputData(throughput_file);
    }
    if (!lock_acquisitions_file.empty()) {
        saveLockAcquisitionsData(lock_acquisitions_file);
    }
    if (!overtakes_file.empty()) {
        saveOvertakesData(overtakes_file);
    }
    if (!overtakes_count_file.empty()) {
        saveOvertakesCountData(overtakes_count_file);
    }
    if (!latency_file.empty()) {
        saveAveragedLatencyData(latency_file);
    }
}



void DataGather::saveThroughputData(const std::string& filename) {
    std::ofstream outfile(outdir+"/"+filename,std::ofstream::app);
    if (outfile) {
        for (const auto& entry : throughput_data) {
            int num_threads = entry.first;
            const auto& throughput_values = entry.second;

            for (const auto& values : throughput_values) {
                for (double value : values) {
                    outfile << lock_name << "," << num_threads << "," << std::fixed << std::setprecision(2) << value << std::endl;
                }
            }
        }
        std::cout << "Throughput data saved to: " << filename << std::endl;
    } else {
        std::cerr << "Failed to write throughput data to file." << std::endl;
    }
}


void DataGather::saveLockAcquisitionsData(const std::string& filename) {
    std::ofstream outfile(outdir+"/"+filename,std::ofstream::app);
    if (outfile) {
        for (const auto& entry : lock_acquisitions_data) {
            int num_threads = entry.first;
            const auto& acquisitions_per_iteration = entry.second;

            for (const auto& acquisitions : acquisitions_per_iteration) {
                for (size_t i = 0; i < acquisitions.size(); i++) {
                    outfile << lock_name << "," << num_threads << ",";
                    for (size_t j = 0; j < acquisitions[i].size(); j++) {
                        outfile << acquisitions[i][j];
                        if (j != acquisitions[i].size() - 1) {
                            outfile << ",";
                        }
                    }
                    outfile << std::endl;
                }
            }
        }
        std::cout << "Lock acquisitions data saved to: " << filename << std::endl;
    } else {
        std::cerr << "Failed to write lock acquisitions data to file." << std::endl;
    }
}


void DataGather::saveOvertakesData(const std::string& filename) {
	std::ofstream outfile(outdir+"/"+filename,std::ofstream::app);
    if (outfile) {
        for (const auto& entry : overtakes_data) {
            int num_threads = entry.first;
            const auto& overtakes_values = entry.second;

            for (size_t i = 0; i < overtakes_values.size(); i++) {
                outfile << lock_name << "," << num_threads << ",";
                for (size_t j = 0; j < overtakes_values[i].size(); j++) {
                    outfile << overtakes_values[i][j];
					if (j != overtakes_values[i].size() - 1) {
                        outfile << ",";
					}
                }
                outfile << std::endl;
            }
        }
        std::cout << "Overtakes data saved to: " << filename << std::endl;
    } else {
        std::cerr << "Failed to write overtakes data to file." << std::endl;
    }
}


void DataGather::saveOvertakesCountData(const std::string& overtakes_count_file) {
	std::ofstream outfile(outdir+"/"+overtakes_count_file,std::ofstream::app);
    if (outfile) {
        for (const auto& entry : overtakes_count_data) {
            int num_threads = entry.first;
			const std::vector<int>& overtakes_count = entry.second;
			int total_iterations = total_iterations_data[num_threads];
			int counter = counter_data[num_threads];
	
            for (int value : overtakes_count) {
				//value++;
				if ( value != num_threads * total_iterations) {
                	outfile << "NOT CORRECT!  " << lock_name << " " << num_threads << " " << value << " " << num_threads * total_iterations  << std::endl;
				}
            }
        }
        std::cout << "correctness data saved to: " << overtakes_count_file << std::endl;
    } else {
        std::cerr << "Failed to write correctness data to file." << std::endl;
    }
}


void DataGather::saveAveragedLatencyData(const std::string& filename) {
    std::ofstream outfile(outdir + "/" + filename, std::ofstream::app);
    if (outfile) {
        for (const auto& entry : averaged_latency_data) {
            int num_threads = entry.first;
            const auto& latency_values = entry.second;

            for (size_t i = 0; i < latency_values.size(); i++) {
                outfile << lock_name << "," << num_threads << ",";
                for (size_t j = 0; j < latency_values[i].size(); j++) {
                    outfile << latency_values[i][j];
                    if (j != latency_values[i].size() - 1) {
                        outfile << ",";
                    }
                }
                outfile << std::endl;
            }
        }
        std::cout << "Averaged latency data saved to: " << filename << std::endl;
    } else {
        std::cerr << "Failed to write averaged latency data to file." << std::endl;
    }
}
