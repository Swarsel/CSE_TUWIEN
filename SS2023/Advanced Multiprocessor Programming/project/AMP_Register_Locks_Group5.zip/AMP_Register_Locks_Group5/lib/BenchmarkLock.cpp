#include <atomic>
#include <vector>
#include <algorithm>
#include "LockBase.hpp"
#include "BenchmarkLock.hpp"
#include "DataGather.hpp"
#include <iostream>
#include <fstream>
#include <chrono>
#include <vector>
#include <string>
#include <cmath>
#include <omp.h>
#include <iomanip>


void Throughput_time(LockBase *Lock, int num_threads, double duration, const std::string& lock_name, DataGather& data_gather) {
    std::vector<double> runtimes;
    int counter = 0;
    auto start_time = std::chrono::high_resolution_clock::now();
    #pragma omp parallel num_threads(num_threads) shared(runtimes)
    {

        #pragma omp barrier

        //double elapsed_time = 0.0;
        auto iteration_start_time = std::chrono::high_resolution_clock::now();

        while (std::chrono::duration<double>(std::chrono::high_resolution_clock::now() - iteration_start_time).count() < duration) {
            Lock->lock();
            counter++;
            Lock->unlock();
        }
    }
    auto end_time = std::chrono::high_resolution_clock::now();
    double total_time = std::chrono::duration<double>(end_time - start_time).count();
	std::vector<double> throughput_values = {counter / total_time};
	data_gather.addBenchmarkResult(num_threads, throughput_values, {}, {}, {}, {},{});	
}

void Throughput_iter(LockBase *Lock, int num_threads, int num_iter, const std::string& lock_name, DataGather& data_gather) {
    std::vector<double> runtimes;
    int counter = 0;
    std::vector<int> num_locks(num_threads, 0);
    auto start_time = std::chrono::high_resolution_clock::now();
    #pragma omp parallel num_threads(num_threads) shared(runtimes)
    {

        auto iteration_start_time = std::chrono::high_resolution_clock::now();
	//	int num_locks_per_thread = 0;
        do {
            Lock->lock();
			counter++;
            Lock->unlock();
        }
		while (counter < num_iter);
    }
    auto end_time = std::chrono::high_resolution_clock::now();
    double total_time = std::chrono::duration<double>(end_time - start_time).count();
    std::vector<double> throughput_values = {counter / total_time};
    data_gather.addBenchmarkResult(num_threads, throughput_values, {}, {}, {}, {},{});
}

void ThroughputSleep_iter(LockBase *Lock, int num_threads, int num_iter, const std::string& lock_name, DataGather& data_gather) {
    std::vector<double> runtimes;
    int counter = 0;
    std::vector<int> num_locks(num_threads, 0);
    auto start_time = std::chrono::high_resolution_clock::now();
    #pragma omp parallel num_threads(num_threads) shared(runtimes)
    {

        auto iteration_start_time = std::chrono::high_resolution_clock::now();
	//int num_locks_per_thread = 0;
	if (omp_get_thread_num() % 4 == 0) {
	  do {
            Lock->lock();
			counter++;
            Lock->unlock();
	  } while (counter < num_iter);
	}
	#pragma omp barrier
    }
    auto end_time = std::chrono::high_resolution_clock::now();
    double total_time = std::chrono::duration<double>(end_time - start_time).count();
    std::vector<double> throughput_values = {counter / total_time};
    data_gather.addBenchmarkResult(num_threads, throughput_values, {}, {}, {}, {},{});
}

void ThroughputSleep_time(LockBase *Lock, int num_threads, int duration, const std::string& lock_name, DataGather& data_gather) {
    int counter = 0;
    std::vector<int> num_locks(num_threads, 0);
    auto start_time = std::chrono::high_resolution_clock::now();
    #pragma omp parallel num_threads(num_threads) 
    {

        auto iteration_start_time = std::chrono::high_resolution_clock::now();
    //int num_locks_per_thread = 0;
    if (omp_get_thread_num() % 4 == 0) {
      do {
            Lock->lock();
            counter++;
            Lock->unlock();
      } while (std::chrono::duration<double>(std::chrono::high_resolution_clock::now() - iteration_start_time).count() < duration);
    }
    #pragma omp barrier
    }
    auto end_time = std::chrono::high_resolution_clock::now();
    double total_time = std::chrono::duration<double>(end_time - start_time).count();
    std::vector<double> throughput_values = {counter / total_time};
    data_gather.addBenchmarkResult(num_threads, throughput_values, {}, {}, {}, {},{});
}




void Latency_iter(LockBase *Lock, int num_threads, int num_iter, const std::string& lock_name, DataGather& data_gather) {
    auto start_time1 = std::chrono::high_resolution_clock::now();
    Lock->lock();
    auto end_time1 = std::chrono::high_resolution_clock::now();
    auto start_time2 = std::chrono::high_resolution_clock::now();
    Lock->unlock();
    auto end_time2 = std::chrono::high_resolution_clock::now();
    double lock_time = std::chrono::duration<double>(end_time1 - start_time1).count();
    double unlock_time = std::chrono::duration<double>(end_time2 - start_time2).count();
    double total_time = lock_time + unlock_time;
    
}


void Latency_time(LockBase *Lock, int num_threads, int duration, const std::string& lock_name, DataGather& data_gather) {
	std::vector<std::vector<double>> latency_values(num_threads);
    int counter = 0;
    auto start_time = std::chrono::high_resolution_clock::now();
    #pragma omp parallel num_threads(num_threads) 
    {

        auto iteration_start_time = std::chrono::high_resolution_clock::now();

        do {
    		auto start_time1 = std::chrono::high_resolution_clock::now();
    		Lock->lock();
    		auto end_time1 = std::chrono::high_resolution_clock::now();
    		Lock->unlock();
			double latency = std::chrono::duration<double>(end_time1 - start_time1).count();
			latency_values[omp_get_thread_num()].push_back(latency);
        	}
        while (std::chrono::duration<double>(std::chrono::high_resolution_clock::now() - iteration_start_time).count() < duration);


    #pragma omp barrier
	}
	std::vector<double> avg_latencies(num_threads);
	        for (int i = 0; i < num_threads; i++) {
            double sum = 0.0;
            	for (double latency : latency_values[i]) {
                	sum += latency;
            }
            avg_latencies[i] = sum / latency_values[i].size();
        }
	data_gather.addBenchmarkResult(num_threads, {}, {}, {}, {}, {}, avg_latencies);

}




void Fairness_time(LockBase *Lock, int num_threads, double duration, const std::string& lock_name, DataGather& data_gather) {
    std::vector<double> runtimes;
    int counter = 0;
	std::vector<int> num_locks(num_threads, 0);
    auto start_time = std::chrono::high_resolution_clock::now();
    #pragma omp parallel num_threads(num_threads) shared(runtimes)
    {

        #pragma omp barrier

        //double elapsed_time = 0.0;
        auto iteration_start_time = std::chrono::high_resolution_clock::now();
		int num_locks_per_thread = 0;
        while (std::chrono::duration<double>(std::chrono::high_resolution_clock::now() - iteration_start_time).count() < duration) {
            Lock->lock();
            counter++;
            num_locks_per_thread++;
            Lock->unlock();
        }
		num_locks[omp_get_thread_num()]=num_locks_per_thread;
    }
    auto end_time = std::chrono::high_resolution_clock::now();
    double total_time = std::chrono::duration<double>(end_time - start_time).count();
    std::vector<double> throughput_values = {counter / total_time};
    data_gather.addBenchmarkResult(num_threads, {}, {num_locks}, {}, 0, {},{});
}



void Fairness_iter(LockBase *Lock, int num_threads, int num_iter, const std::string& lock_name, DataGather& data_gather) {
    std::vector<int> num_locks(num_threads, 0);
	int counter = 0;
    #pragma omp parallel num_threads(num_threads)
    {

        int num_locks_per_thread = 0;
        do {
            Lock->lock();
            num_locks_per_thread++;
			counter++;
            Lock->unlock();
        }
        while (counter < num_iter);
        num_locks[omp_get_thread_num()]=num_locks_per_thread;
    }
    data_gather.addBenchmarkResult(num_threads, {}, {num_locks}, {}, 0, num_threads * num_iter,{});
}

void OvertakeCorrectness_iter(LockBase *Lock, int num_threads, int num_iter, const std::string& lock_name, DataGather& data_gather) {
    int total_sum = 0;
	int counter = 0;
	std::vector<int> overtakes (num_threads,0);
	int n_threads = num_threads;
    #pragma omp parallel num_threads(num_threads) 
    {
        int num_locks_per_thread = 0;
        for (int i = 0; i < num_iter; i++) {
         
            Lock->lockOvertake();
			counter++;
            Lock->unlock();

        }
		#pragma omp barrier
    }
	std::vector<int> T = Lock->T;
    for (int i = 0; i < n_threads; i++) {
        std::vector<int>::iterator start = T.begin();
        std::vector<int>::iterator end = T.end();
        for (int j=0; j < num_iter; j++) {
            start = std::find(start, T.end(), i);
            end = std::find(start+1, T.end(), i+n_threads);
            int overtake = 0;
            for (int k=0; k<num_threads; k++) {
                overtake += std::count(start, end, k+n_threads);
                                if ((std::find(start, end, k+n_threads) -std::find(start, end, k)) < 0) {
                                        overtake--;
                                }
                        }
			if (overtake > overtakes[i]) {
            	overtakes[i] = overtake;
			}
            start = end+1;
        }
    }

    data_gather.addBenchmarkResult(num_threads, {}, {}, overtakes, counter, num_iter,{});
}

