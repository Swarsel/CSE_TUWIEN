#include <iostream>
#include <vector>
#include <algorithm>
#include <atomic>
#include <omp.h>
#include "FilterLock.hpp"

using namespace std;

FilterLock::FilterLock(int num_threads) {
	n = num_threads;
	//level = new int[n];
	//victim = new int[n];
	level = new atomic<int>[n];
    	victim = new atomic<int>[n];
	for (int i = 0; i < n; i++) {
		level[i]=0;
	}
}

FilterLock::~FilterLock() {
	delete[] level;
	delete[] victim;
}

void FilterLock::lock() {
	int me = omp_get_thread_num();
	for (int i = 1; i < n; i++) {
		//level[me] = i;
		//victim[i] = me;
	    
		level[me].store(i);
		victim[i].store(me);
		int j = 0;
		while (j < n) {
			//while ((j != me) && (level[j] >= i && victim[i] == me )) {
			while ((j != me) && (level[j].load() >= i && victim[i].load() == me)) {
			}
			j++;
		}
	}
	
}

void FilterLock::lockOvertake() {
	int me = omp_get_thread_num();
	for (int i = 1; i < n; i++) {
		//level[me] = i;
		//victim[i] = me;
		if (i==1) {
            #pragma omp critical
            {
                T.push_back(omp_get_thread_num());
				level[me].store(i);
            }
        }
		else level[me].store(i);
		victim[i].store(me);
		int j = 0;
		while (j < n) {
			//while ((j != me) && (level[j] >= i && victim[i] == me )) {
			while ((j != me) && (level[j].load() >= i && victim[i].load() == me)) {
			}
			j++;
		}
	}
	#pragma omp critical
    {
        T.push_back(omp_get_thread_num()+n);
    }
}


void FilterLock::unlock() {
	int me = omp_get_thread_num();
	//level[me] = 0;
	level[me].store(0);
}
