#include "PetersonLock2.hpp"
#include <omp.h>
#include <thread>

PetersonLock2::PetersonLock2(int index) : index(index) {
	victim.store(0);
	flag[0].store(false);
	flag[1].store(false);
}

PetersonLock2::~PetersonLock2() {
}

void PetersonLock2::lock() {
	int i;
	if (omp_get_thread_num() < index) {
		i = 0;
	}
	else {
		i = 1;
	}
	int j = 1 - i;
	flag[i].store(true);
	victim.store(i);
	while (flag[j].load() && victim.load() == i) {
	}
}

void PetersonLock2::unlock() {
	int i;
	if (omp_get_thread_num() < index) {
		i = 0;
	}
	else {
		i = 1;
	}
	flag[i].store(false);
}
