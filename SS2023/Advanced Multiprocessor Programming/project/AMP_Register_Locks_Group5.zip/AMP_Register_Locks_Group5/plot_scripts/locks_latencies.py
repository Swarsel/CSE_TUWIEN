import sys
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import io
import os

def plot_latencies(input_file, num_threads, output_dir):
    # Read the data from the input file
    filtered_rows = []
    with open(input_file, 'r') as file:
        for line in file:
            columns = line.strip().split(',')
            if int(columns[1]) == num_threads:  # Check if the row has enough columns
                filtered_rows.append(line)

    # Read the filtered data into a DataFrame
    df = pd.read_csv(io.StringIO('\n'.join(filtered_rows)),
                     delimiter=",",
                     names=["LockName", "NumThreads"] + [f"Thread{i}" for i in range(num_threads)])


    # Filter the data for the specified number of threads
    filtered_df = df[df["NumThreads"] == num_threads]


    # Get the lock name
    lock_name = filtered_df["LockName"].iloc[0]

    # Collect latencies for each thread
    thread_latencies = []
    for i in range(num_threads):
        thread_data = filtered_df[f"Thread{i}"].values
        thread_latencies.append(thread_data)
    thread_avg_latencies = np.mean(thread_latencies, axis=1)
    thread_std_latencies = np.std(thread_latencies, axis=1)
    thread_se_latencies = thread_std_latencies / np.sqrt(len(thread_latencies[0]))

    # Plot the latencies per thread
    fig, ax = plt.subplots()
    if num_threads > 30:
        fig.set_size_inches(20, 6)
    #ax.boxplot(thread_latencies)
    ax.bar(range(num_threads), thread_avg_latencies, yerr=thread_std_latencies, capsize=5)
    ax.set_xticks(range(num_threads))
    ax.set_xticklabels([f"{i}" for i in range(num_threads)])
    ax.set_xlabel("Thread")
    ax.set_ylabel("Latency")
    ax.set_title(f"Latency Distribution ({lock_name})")

    ax.ticklabel_format(style='sci', axis='y', scilimits=(0, 0))

    plt.savefig(f"{output_dir}/latency/{lock_name}_num_threads_{num_threads}.png")

    # Calculate statistics
    mean_latencies = np.mean(thread_latencies, axis=1)
    max_latencies = np.max(thread_latencies, axis=1)
    min_latencies = np.min(thread_latencies, axis=1)
    std_latencies = np.std(thread_latencies, axis=1)

    print("Statistics:")
    print("-----------")
    print(f"Mean Latency: {mean_latencies}")
    print(f"Max Latency: {max_latencies}")
    print(f"Min Latency: {min_latencies}")
    print(f"Standard Deviation: {std_latencies}")


if __name__ == "__main__":
    # Check if the required command-line arguments are provided
    if len(sys.argv) < 4:
        print("Usage: python plot_latencies.py <input_file> <num_threads> <output_dir>")
        sys.exit(1)

    # Get the input file, number of threads, and output directory from command-line arguments
    input_file = sys.argv[1]
    num_threads = int(sys.argv[2])
    output_dir = sys.argv[3]
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)


    # Call the function to plot and calculate statistics
    plot_latencies(input_file, num_threads, output_dir)
