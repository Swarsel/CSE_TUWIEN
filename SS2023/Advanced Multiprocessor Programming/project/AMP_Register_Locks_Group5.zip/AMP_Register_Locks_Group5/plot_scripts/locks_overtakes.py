import sys
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import io
import os

def plot_lock_overtakes(input_file, num_threads):
    # Read the data from the input file
    #df = pd.read_csv(input_file, delimiter=",", names=["LockName", "NumThreads"] + [f"Thread{i}" for i in range(num_threads)])
    filtered_rows = []
    with open(input_file, 'r') as file:
        for line in file:
            columns = line.strip().split(',')
            if int(columns[1]) == num_threads:  # Check if the row has enough columns
                filtered_rows.append(line)

    # Read the filtered data into a DataFrame
    df = pd.read_csv(io.StringIO('\n'.join(filtered_rows)),
                     delimiter=",",
                     names=["LockName", "NumThreads"] + [f"Thread{i}" for i in range(num_threads)])


    # Filter the data for the specified number of threads
    filtered_df = df[df["NumThreads"] == num_threads]
    
    lock_name = df["LockName"].iloc[0]

    # Average the lock acquisitions over iterations for each thread
    thread_acquisitions_max = []
    for i in range(num_threads):
        thread_data = []
        for _, row in filtered_df.iterrows():
            thread_data.append(row[f"Thread{i}"])
        thread_acquisitions_max.append(max(thread_data))

    # Plot the highest acquired overtakes per thread
    fig, ax = plt.subplots()
    if (num_threads > 30):
        fig, ax = plt.subplots(figsize=(20, 6))

    ax.bar(range(num_threads), thread_acquisitions_max)
    ax.set_xticks(range(num_threads))
    ax.set_xticklabels([f"{i}" for i in range(num_threads)])
    ax.set_xlabel("Thread")
    ax.set_ylabel("Highest Lock overtakes")
    ax.set_title(f"Highest number of times a Thread gets overtaken ({lock_name})")
    if (str(lock_name) == "alagarsamylock"):
        ax.axhline(num_threads-1, color='red', linestyle='dashed')
    if (str(lock_name) == "blockwoolock"):
        ax.axhline(num_threads*(num_threads-1)/2, color='red', linestyle='dashed')
    ax.legend()
    plt.savefig(str(output_dir)+"/overtake/"+str(lock_name)+"_num_threads"+str(num_threads)+".png")



if __name__ == "__main__":
    # Check if the required command-line arguments are provided
    if len(sys.argv) < 4:
        print("Usage: python plot_lock_overtakes.py <input_file> <num_threads> <outputdir>")
        sys.exit(1)

    # Get the input file and number of threads from command-line arguments
    input_file = sys.argv[1]
    num_threads = int(sys.argv[2])
    output_dir = sys.argv[3]
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    plot_lock_overtakes(input_file, num_threads)
