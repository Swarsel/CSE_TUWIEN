#!/bin/python

import sys
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

if len(sys.argv) < 2:
    print("Usage: python plot_throughput.py <input_files> <output_dir>")
    sys.exit(1)

input_files = sys.argv[1:]

dfs = []

# Read the throughput data from each input file
for input_file in input_files:
    df = pd.read_csv(input_file, delimiter=",", names=["LockType", "NumThreads", "Throughput"])
    dfs.append(df)

# Combine the data frames from different input files
combined_df = pd.concat(dfs)

# Group the data by lock type and number of threads
grouped_data = combined_df.groupby(["LockType", "NumThreads"])

# Calculate the mean and standard deviation of throughput for each lock type and number of threads
mean_throughput = grouped_data["Throughput"].mean()
std_throughput = grouped_data["Throughput"].std()
n_samples = grouped_data["Throughput"].count()
se_throughput = grouped_data["Throughput"].std() / np.sqrt(n_samples)  # Standard error


# Get unique lock types and number of threads
lock_types = mean_throughput.index.get_level_values("LockType").unique()
num_threads = mean_throughput.index.get_level_values("NumThreads").unique()

# Set up the plot
fig, ax = plt.subplots()

# Calculate the width of each column
column_width = 0.8 / len(lock_types)

# Plot the columns and error bars
for i, lock_type in enumerate(lock_types):
    data = mean_throughput[lock_type]
    #errors = std_throughput[lock_type]
    errors = se_throughput[lock_type]
    x = np.arange(len(num_threads)) + i * column_width
    
    ax.bar(x, data, yerr=errors, width=column_width, align="center", label=lock_type)

plt.xlabel("Number of Threads")
plt.ylabel("Throughput [Locks/s]")
plt.title("Throughput")
plt.xticks(np.arange(len(num_threads)) + (len(lock_types) - 1) * column_width / 2, num_threads)
#plt.yscale("log")  # Set log scale on the y-axis
plt.legend()
#plt.show()
plt.savefig("plots/throughput_all_locks.png")

# Print the statistics
for (lock_type, num_threads), mean, std in zip(mean_throughput.index, mean_throughput.values, std_throughput.values):
    print(f"Lock Type: {lock_type}")
    print(f"Number of Threads: {num_threads}")
    print(f"Mean Throughput: {mean}")
    print(f"Standard Deviation: {std}")
    print()
