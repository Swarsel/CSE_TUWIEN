import sys
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import io
import os

def plot_lock_acquired(input_file, num_threads):
    # Read the data from the input file
    #df = pd.read_csv(input_file, delimiter=",", names=["LockName", "NumThreads"] + [f"Thread{i}" for i in range(num_threads)])
    filtered_rows = []
    with open(input_file, 'r') as file:
        for line in file:
            columns = line.strip().split(',')
            if int(columns[1]) == num_threads:  # Check if the row has enough columns
                filtered_rows.append(line)

    # Read the filtered data into a DataFrame
    df = pd.read_csv(io.StringIO('\n'.join(filtered_rows)),
                     delimiter=",",
                     names=["LockName", "NumThreads"] + [f"Thread{i}" for i in range(num_threads)])

    # Filter the data for the specified number of threads
    filtered_df = df[df["NumThreads"] == num_threads]
    #print(filtered_df)
    
    #lock_name = df["LockName"].iloc[0]
    lock_name = filtered_df["LockName"].iloc[0]

    # Average the lock acquisitions over iterations for each thread
    thread_acquisitions_avg = []
    thread_acquisitions_std = []
    thread_acquisitions_se = []
    for i in range(num_threads):
        #plt.boxplot(filtered_df[f"Thread{i}"].values)
        #print(filtered_df[f"Thread{i}"].values)
        thread_data = filtered_df[f"Thread{i}"].values
        thread_acquisitions_avg.append(np.mean(thread_data))
        thread_acquisitions_std.append(np.std(thread_data))
        thread_acquisitions_se.append(np.std(thread_data)/np.sqrt(len(thread_data)))

    # Plot the acquired locks per thread with error bars
    fig, ax = plt.subplots()
    if (num_threads > 30):
        fig, ax = plt.subplots(figsize=(20, 6))
    ax.bar(range(num_threads), thread_acquisitions_avg, yerr=thread_acquisitions_std, capsize=5)
    #plt.boxplot(filtered_df)
    ax.set_xticks(range(num_threads))
    ax.set_xticklabels([f"{i}" for i in range(num_threads)])
    ax.set_xlabel("Thread")
    ax.set_ylabel("Average Lock Acquired")
    ax.set_title(f"Average number acquired locks ({lock_name})")
    #plt.show()
    plt.savefig(str(output_dir)+"/fairness/"+str(lock_name)+"_num_threads"+str(num_threads)+".png")

    # Calculate statistics
    mean_acquisitions = np.mean(thread_acquisitions_avg)
    max_acquisitions = np.max(thread_acquisitions_avg)
    min_acquisitions = np.min(thread_acquisitions_avg)
    std_acquisitions = np.mean(thread_acquisitions_std)

    #print("Statistics:")
    print("-----------")
    print(f"Mean Acquisitions: {mean_acquisitions}")
    print(f"Max Acquisitions: {max_acquisitions}")
    print(f"Min Acquisitions: {min_acquisitions}")
    print(f"Standard Deviation: {std_acquisitions}")


if __name__ == "__main__":
    # Check if the required command-line arguments are provided
    if len(sys.argv) < 4:
        print("Usage: python plot_lock_overtakes.py <input_file> <num_threads> <output_dir>")
        sys.exit(1)

    # Get the input file and number of threads from command-line arguments
    input_file = sys.argv[1]
    num_threads = int(sys.argv[2])
    output_dir = sys.argv[3]

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)


    # Call the function to plot and calculate statistics
    plot_lock_acquired(input_file, num_threads)

