
alias ll="ls -alh"
export PATH="$PATH:./bin/"
