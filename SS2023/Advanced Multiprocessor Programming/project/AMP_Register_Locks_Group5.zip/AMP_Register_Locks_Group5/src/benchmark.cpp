#include "FilterLock.hpp"
#include "OpenmpLock.hpp"
#include "PetersonLock2.hpp"
#include "BenchmarkLock.hpp"
#include "DataGather.hpp"
#include "BlockWooLock.hpp"
#include "AlagarsamyLock2.hpp"
#include "Tree.hpp"
#include <iostream>
#include <fstream>
#include <chrono>
#include <vector>
#include <string>
#include <cmath>
#include <set>
#include <omp.h>
#include <iomanip>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>


int main(int argc, char* argv[]) {
    if (argc < 6 || argc > 7) {
        std::cerr << "Usage: " << argv[0] << " <lockname> <benchmarktype> <num_iterations> <num_threads> <duration> <outdir>" << std::endl;
        std::cerr << "Possible values for lockname: filter, openmp, blockwoo, tree, alagarsamy" << std::endl;
        std::cerr << "Possible values for benchmarktype: throughput, throughputsleep, fairness, overtake" << std::endl;
        return 1;
    }
		// check which arguments were passed
		std::set<std::string> locknames{"filter", "openmp", "blockwoo", "tree", "alagarsamy"};
		std::set<std::string> benchmarktypes{"throughput", "throughputsleep", "fairness", "overtake","latency"};
		std::string locktype = argv[1];
		std::string benchtype = argv[2];
    	
	if ((locknames.find(locktype) == locknames.end()) || (benchmarktypes.find(benchtype) == benchmarktypes.end()))  {
		std::cerr << "Usage: " << argv[0] << " <lockname> <benchmarktype> <num_iterations> <num_runs>" << std::endl;
		std::cerr << "Possible values for lockname: filter, openmp, blockwoo, tree, alagarsamy" << std::endl;
		std::cerr << "Possible values for benchmarktype: throughput, throughputsleep, fairness, overtake" << std::endl;
	  return 1;
    }

	int num_iterations = std::stoi(argv[3]);
	int num_threads = std::stod(argv[4]);
	int duration = std::stod(argv[5]);
	std::string outdir;
	if (argc == 7) {
        outdir = argv[6];
    } else {
        outdir = ".";
	}

	/*if (mkdir(outdir.c_str(), 0777) == -1) {
    	std::cerr << "Failed to create directory: " << outdir << std::endl;
		return 1;
	}*/

	LockBase* Lock = nullptr;
	DataGather filter_data_gather("FilterLock");
	DataGather openmp_data_gather("OpenmpLock");
	DataGather blockwoo_data_gather("BlockWooLock");
	DataGather tree_data_gather("TreeLock");
	DataGather alagarsamy_data_gather("AlagarsamyLock");
	std::map<std::string, DataGather> lockDataMap = {
    {"filterlock", filter_data_gather},
    {"openmplock", openmp_data_gather},
    {"blockwoolock", blockwoo_data_gather},
    {"treelock", tree_data_gather},
    {"alagarsamylock", alagarsamy_data_gather}
	};

	if (locktype == "filter") {
		Lock = new FilterLock(num_threads);
	}
	if (locktype == "openmp") {
		Lock = new OpenmpLock(num_threads);
	}
	if (locktype == "blockwoo") {
		Lock = new BlockWooLock(num_threads);
	}
	if (locktype == "tree") {
		Lock = new Tree(num_threads);
	}
	if (locktype == "alagarsamy") {
		Lock = new AlagarsamyLock2(num_threads);
	}
		
    if (benchtype == "throughput") {
		//Throughput_iter(Lock, num_threads, num_iterations, locktype, lockDataMap[locktype]);
		Throughput_time(Lock, num_threads, duration, locktype, lockDataMap[locktype]);
	}
	if (benchtype == "throughputsleep") {
		ThroughputSleep_time(Lock, num_threads, duration, locktype, lockDataMap[locktype]);
	}
    if (benchtype == "latency") {
		Latency_time(Lock, num_threads, duration, locktype, lockDataMap[locktype]);
	}			 
	if (benchtype == "fairness") {
		//Fairness_iter(Lock, num_threads, num_iterations, locktype, lockDataMap[locktype]);
		Fairness_time(Lock, num_threads, duration, locktype, lockDataMap[locktype]);
	}
	if (benchtype == "overtake") {
		OvertakeCorrectness_iter(Lock, num_threads, num_iterations, locktype, lockDataMap[locktype]);
	}

	lockDataMap[locktype].setLocktype(locktype+"lock");
	lockDataMap[locktype].setOutdir(outdir);
    if (benchtype == "throughput") {
        lockDataMap[locktype].saveResults(std::string(locktype)+"_throughput.txt", "", "", "","");
    }
    if (benchtype == "throughputsleep") {
        lockDataMap[locktype].saveResults(std::string(locktype)+"_throughputsleep.txt", "", "", "","");
    }
	if (benchtype == "fairness") {
        lockDataMap[locktype].saveResults("", std::string(locktype)+"_acquisitions.txt", "", "","");
    }
	
	if (benchtype == "overtake") {
        lockDataMap[locktype].saveResults("", "", std::string(locktype)+"_overtakes.txt", std::string(locktype)+"_correctness.txt","");
	}
	if (benchtype == "latency") {
        lockDataMap[locktype].saveResults("", "", "", "", std::string(locktype)+"_latency.txt");
    }


	return 0;
}

