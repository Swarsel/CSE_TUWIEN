#!/bin/bash

python ./plot_scripts/multiple_locks_throughput_new.py res_small_bench/filter_throughput.txt res_small_bench/alagarsamy_throughput.txt res_small_bench/blockwoo_throughput.txt  res_small_bench/openmp_throughput.txt res_small_bench/tree_throughput.txt plots
python ./plot_scripts/multiple_locks_throughputsleep.py res_small_bench/alagarsamy_throughputsleep.txt res_small_bench/blockwoo_throughputsleep.txt plots

python ./plot_scripts/locks_acquired.py res_small_bench/tree_acquisitions.txt 5 plots
python ./plot_scripts/locks_acquired.py res_small_bench/tree_acquisitions.txt 8 plots 
python ./plot_scripts/locks_acquired.py res_small_bench/alagarsamy_acquisitions.txt 5 plots
python ./plot_scripts/locks_acquired.py res_small_bench/alagarsamy_acquisitions.txt 8 plots

python ./plot_scripts/locks_overtakes.py res_small_bench/alagarsamy_overtakes.txt 8 plots
python ./plot_scripts/locks_overtakes.py res_small_bench/blockwoo_overtakes.txt 8 plots
python ./plot_scripts/locks_overtakes.py res_small_bench/filter_overtakes.txt 8 plots

python ./plot_scripts/locks_latencies.py res_small_bench/alagarsamy_latency.txt 32 plots
python ./plot_scripts/locks_latencies.py res_small_bench/openmp_latency.txt 32 plots


echo "Throughput plot for all locks: plots/throughput_all_locks.png"
echo "Throughputsleep plot for all locks: plots/throughputsleep_all_locks.png"
echo "Fairnessplot alagarsamy with 5 threads in plots/fairness/alagarsamylock_num_threads5.png"
echo "Fairnessplot alagarsamy with 8 threads in plots/fairness/alagarsamylock_num_threads8.png"
echo "Fairnessplot tree with 5 threads in plots/fairness/treelock_num_threads5.png"
echo "Fairnessplot tree with 8 threads in plots/fairness/treelock_num_threads8.png"
echo "Overtakeplot alagarsamy with 8 threads in plots/overtake/alagarsamylock_num_threads8.png"
echo "Overtakeplot blockwoo with 8 threads in plots/overtake/blockwoolock_num_threads8.png"
echo "Overtakeplot filter with 8 threads in plots/overtake/filterlock_num_threads8.png"


echo "Latencyplot alagarsamy with 32 threads in plots/latency/alagarsamy_num_threads32.png"
echo "Latencyplot openmp with 32 threads in plots/latency/openmp_num_threads32.png"

