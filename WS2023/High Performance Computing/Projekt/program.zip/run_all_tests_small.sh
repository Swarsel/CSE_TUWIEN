#!/bin/bash

./run_tests_small.sh p2p
./run_tests_small.sh p2pc
./run_tests_small.sh coll



